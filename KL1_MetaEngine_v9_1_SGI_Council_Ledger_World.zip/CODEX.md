
# Working with GPT Codex on KL1 MetaEngine

## Goal
Keep the meta-engine laminar: **Council (PIM) + Pipelines (DataFlow) + Ledger + WorldLayer**.
Domain apps (ToE/ToL/Biz) should stay as plugins over this kernel.

## Tasks Codex should do next (safe order)
1) Replace placeholder operators in `pipelines/operators/ingest.py` with real ingestors **behind interfaces**.
2) Add verifiers in `pipelines/operators/verify.py`:
   - citation verifier (source URLs),
   - math sanity checks,
   - regression tests for code paths.
3) Expand ToL `books/spine.py` into chapter generator that writes Markdown to `outputs/books/`.
4) Expand ToE equation tracker:
   - endpoint to attach tests + predictions to each equation,
   - scoring rubric (falsifiability, fit, novelty, consistency).
5) Add deduplication on `knowledge_items` via content hash / URL canonicalization.

## Rules
- No cross-domain imports (ToE cannot import Biz logic, etc.).
- All new ingestion must output `KnowledgeItem`.
- Any self-modification must pass verifiers/tests.
