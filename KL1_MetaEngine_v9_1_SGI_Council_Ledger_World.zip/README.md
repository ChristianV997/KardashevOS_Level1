
# KL1 MetaEngine v9.1 — SGI Council + Ledger (Clean Kernel)

## Run (local)
```bash
pip install -r requirements.txt
uvicorn api.main:app --reload
```

## Run (Docker)
```bash
docker compose up --build
```

## Key Endpoints (n8n-ready)
- POST `/v1/automation/ingest` — ingest `KnowledgeItem`
- POST `/v1/council/cycle` — run council PIM cycle
- GET  `/v1/next-run` — get next objectives from ledger
- POST `/v1/equations/upsert` — add/update equation candidate
- GET  `/v1/equations` — list equations
- POST `/v1/world/node` — world graph node (state/snooze/provenance)
- POST `/v1/world/edge` — world graph edge (correlation/causality)
- GET  `/v1/world/graph` — fetch graph

## n8n
Import: `automations/n8n_templates/KL1_Council_Cycle_Email.json`
Set env:
- `BASE_URL` (e.g. https://your-vps-domain)
- `EMAIL_FROM`, `EMAIL_TO`
