
class SharedState:
    """Shared in-process state (Nightjar-style). Durable state lives in SQLite."""
    def __init__(self):
        self.memory = {}
        self.context = {}
        self.metrics = {}

STATE = SharedState()
