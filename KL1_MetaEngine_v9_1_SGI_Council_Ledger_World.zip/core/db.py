
import os
import sqlite3
from contextlib import contextmanager

DB_PATH = os.getenv("KL1_DB_PATH", "data/kl1.db")

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS ledger (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            domain TEXT NOT NULL,
            hypothesis TEXT NOT NULL,
            evidence_json TEXT NOT NULL,
            confidence REAL NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS knowledge_items (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            title TEXT NOT NULL,
            source TEXT,
            url TEXT,
            tags_json TEXT,
            gps_score REAL,
            summary TEXT,
            payload_json TEXT,
            created_at TEXT NOT NULL
        );
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS equations (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            latex TEXT NOT NULL,
            domain TEXT,
            status TEXT,
            gps_score REAL,
            notes TEXT,
            metadata_json TEXT,
            created_at TEXT NOT NULL
        );
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS world_nodes (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            title TEXT NOT NULL,
            state TEXT NOT NULL,
            snooze_until TEXT,
            provenance_json TEXT,
            payload_json TEXT,
            updated_at TEXT NOT NULL
        );
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS world_edges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            src TEXT NOT NULL,
            dst TEXT NOT NULL,
            kind TEXT NOT NULL,
            weight REAL,
            evidence_json TEXT,
            created_at TEXT NOT NULL
        );
        """)

@contextmanager
def connect():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    try:
        yield con
    finally:
        con.close()
