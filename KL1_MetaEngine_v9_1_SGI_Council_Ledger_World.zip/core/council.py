
from services.ledger import ledger_service
from services.knowledge import knowledge_service
from agents.toe_agent import ToEAgent
from agents.tol_agent import ToLAgent
from agents.biz_agent import BizAgent

class Council:
    def __init__(self):
        self.agents = [ToEAgent(), ToLAgent(), BizAgent()]

    def run_cycle(self, pipeline):
        outputs = []
        for agent in self.agents:
            context = agent.deliberate(ledger_service, knowledge_service)
            plan = agent.conceive(context)
            result = agent.act(pipeline, plan)
            insight = agent.perceive(result)
            ledger_service.add(agent.domain, plan, result, insight.get("confidence", 0.5))
            outputs.append({"domain": agent.domain, "plan": plan, **insight})
        return outputs
