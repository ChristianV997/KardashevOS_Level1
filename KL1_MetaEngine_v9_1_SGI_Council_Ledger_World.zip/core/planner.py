
from services.ledger import ledger_service

def next_run_plan(threshold=0.6, limit=10):
    items = ledger_service.top(None, limit=200)
    return [e for e in items if e["confidence"] >= threshold][:limit]
