
from core.council import Council
from pipelines.runner import PipelineRunner

def run_once():
    runner = PipelineRunner()
    council = Council()
    return council.run_cycle(runner)
