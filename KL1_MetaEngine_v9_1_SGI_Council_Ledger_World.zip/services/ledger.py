
import json
from datetime import datetime
from core.db import connect, init_db

init_db()

class LedgerService:
    def add(self, domain: str, hypothesis: str, evidence: dict, confidence: float):
        with connect() as con:
            con.execute(
                "INSERT INTO ledger(domain,hypothesis,evidence_json,confidence,created_at) VALUES(?,?,?,?,?)",
                (domain, hypothesis, json.dumps(evidence, ensure_ascii=False), float(confidence), datetime.utcnow().isoformat()),
            )
            con.commit()

    def top(self, domain: str | None = None, limit: int = 10):
        q = "SELECT domain,hypothesis,evidence_json,confidence,created_at FROM ledger"
        params = ()
        if domain:
            q += " WHERE domain=?"
            params = (domain,)
        q += " ORDER BY confidence DESC, created_at DESC LIMIT ?"
        params = params + (limit,)
        with connect() as con:
            rows = con.execute(q, params).fetchall()
        out = []
        for d,h,e,c,t in rows:
            out.append({"domain": d, "hypothesis": h, "evidence": json.loads(e), "confidence": c, "created_at": t})
        return out

ledger_service = LedgerService()
