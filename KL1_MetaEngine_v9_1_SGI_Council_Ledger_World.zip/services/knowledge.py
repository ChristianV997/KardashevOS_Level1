
import json
from datetime import datetime
from core.db import connect, init_db
from models.knowledge_item import KnowledgeItem

init_db()

class KnowledgeService:
    def upsert(self, item: KnowledgeItem) -> KnowledgeItem:
        with connect() as con:
            con.execute(
                """
                INSERT INTO knowledge_items(id,kind,title,source,url,tags_json,gps_score,summary,payload_json,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    kind=excluded.kind,
                    title=excluded.title,
                    source=excluded.source,
                    url=excluded.url,
                    tags_json=excluded.tags_json,
                    gps_score=excluded.gps_score,
                    summary=excluded.summary,
                    payload_json=excluded.payload_json
                """,
                (
                    item.id,
                    item.kind,
                    item.title,
                    item.source,
                    item.url,
                    json.dumps(item.tags, ensure_ascii=False),
                    item.gps_score,
                    item.summary,
                    json.dumps(item.payload or {}, ensure_ascii=False),
                    item.created_at.isoformat(),
                ),
            )
            con.commit()
        return item

    def recent(self, limit: int = 50):
        with connect() as con:
            rows = con.execute(
                "SELECT id,kind,title,source,url,tags_json,gps_score,summary,payload_json,created_at FROM knowledge_items ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        out=[]
        for r in rows:
            out.append({
                "id": r[0], "kind": r[1], "title": r[2], "source": r[3], "url": r[4],
                "tags": json.loads(r[5] or "[]"), "gps_score": r[6], "summary": r[7],
                "payload": json.loads(r[8] or "{}"), "created_at": r[9]
            })
        return out

knowledge_service = KnowledgeService()
