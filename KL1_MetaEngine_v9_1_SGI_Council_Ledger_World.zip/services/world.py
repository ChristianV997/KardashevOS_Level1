
import json
from datetime import datetime
from core.db import connect, init_db
from models.world import WorldNode, WorldEdge

init_db()

class WorldService:
    def upsert_node(self, node: WorldNode) -> WorldNode:
        with connect() as con:
            con.execute(
                """
                INSERT INTO world_nodes(id,kind,title,state,snooze_until,provenance_json,payload_json,updated_at)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    kind=excluded.kind,
                    title=excluded.title,
                    state=excluded.state,
                    snooze_until=excluded.snooze_until,
                    provenance_json=excluded.provenance_json,
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (
                    node.id, node.kind, node.title, node.state,
                    node.snooze_until.isoformat() if node.snooze_until else None,
                    json.dumps(node.provenance, ensure_ascii=False),
                    json.dumps(node.payload, ensure_ascii=False),
                    datetime.utcnow().isoformat(),
                ),
            )
            con.commit()
        return node

    def add_edge(self, edge: WorldEdge) -> WorldEdge:
        with connect() as con:
            con.execute(
                "INSERT INTO world_edges(src,dst,kind,weight,evidence_json,created_at) VALUES(?,?,?,?,?,?)",
                (edge.src, edge.dst, edge.kind, float(edge.weight), json.dumps(edge.evidence, ensure_ascii=False), datetime.utcnow().isoformat()),
            )
            con.commit()
        return edge

    def graph(self, limit_nodes: int = 500, limit_edges: int = 2000):
        with connect() as con:
            nodes = con.execute(
                "SELECT id,kind,title,state,snooze_until,provenance_json,payload_json,updated_at FROM world_nodes ORDER BY updated_at DESC LIMIT ?",
                (limit_nodes,),
            ).fetchall()
            edges = con.execute(
                "SELECT src,dst,kind,weight,evidence_json,created_at FROM world_edges ORDER BY created_at DESC LIMIT ?",
                (limit_edges,),
            ).fetchall()
        n_out=[]
        for r in nodes:
            n_out.append({
                "id": r[0], "kind": r[1], "title": r[2], "state": r[3], "snooze_until": r[4],
                "provenance": json.loads(r[5] or "{}"), "payload": json.loads(r[6] or "{}"), "updated_at": r[7]
            })
        e_out=[]
        for r in edges:
            e_out.append({"src": r[0], "dst": r[1], "kind": r[2], "weight": r[3], "evidence": json.loads(r[4] or "{}"), "created_at": r[5]})
        return {"nodes": n_out, "edges": e_out}

world_service = WorldService()
