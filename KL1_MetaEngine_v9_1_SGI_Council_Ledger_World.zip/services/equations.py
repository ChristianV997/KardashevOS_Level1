
import json
from datetime import datetime
from core.db import connect, init_db
from models.equation import Equation

init_db()

class EquationService:
    def upsert(self, eq: Equation) -> Equation:
        with connect() as con:
            con.execute(
                """
                INSERT INTO equations(id,name,latex,domain,status,gps_score,notes,metadata_json,created_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name,
                    latex=excluded.latex,
                    domain=excluded.domain,
                    status=excluded.status,
                    gps_score=excluded.gps_score,
                    notes=excluded.notes,
                    metadata_json=excluded.metadata_json
                """,
                (
                    eq.id, eq.name, eq.latex, eq.domain, eq.status, eq.gps_score, eq.notes,
                    json.dumps(eq.metadata or {}, ensure_ascii=False),
                    eq.created_at.isoformat(),
                ),
            )
            con.commit()
        return eq

    def list(self, limit: int = 100):
        with connect() as con:
            rows = con.execute(
                "SELECT id,name,latex,domain,status,gps_score,notes,metadata_json,created_at FROM equations ORDER BY gps_score DESC NULLS LAST, created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        out=[]
        for r in rows:
            out.append({
                "id": r[0], "name": r[1], "latex": r[2], "domain": r[3], "status": r[4],
                "gps_score": r[5], "notes": r[6], "metadata": json.loads(r[7] or "{}"), "created_at": r[8]
            })
        return out

equation_service = EquationService()
