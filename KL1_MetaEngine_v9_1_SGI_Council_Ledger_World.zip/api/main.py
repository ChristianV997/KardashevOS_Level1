
from fastapi import FastAPI
from pydantic import BaseModel
from core.engine import run_once
from core.planner import next_run_plan
from models.knowledge_item import KnowledgeItem
from models.equation import Equation
from models.world import WorldNode, WorldEdge
from services.knowledge import knowledge_service
from services.equations import equation_service
from services.world import world_service

app = FastAPI(title="KL1 MetaEngine v9.1 (SGI Council)")

class CycleResponse(BaseModel):
    outputs: list

@app.post("/v1/automation/ingest")
def ingest(item: KnowledgeItem):
    return knowledge_service.upsert(item)

@app.post("/v1/council/cycle", response_model=CycleResponse)
def council_cycle():
    return {"outputs": run_once()}

@app.get("/v1/next-run")
def next_run():
    return next_run_plan()

@app.post("/v1/equations/upsert")
def upsert_equation(eq: Equation):
    return equation_service.upsert(eq)

@app.get("/v1/equations")
def list_equations(limit: int = 100):
    return equation_service.list(limit=limit)

@app.post("/v1/world/node")
def upsert_node(node: WorldNode):
    return world_service.upsert_node(node)

@app.post("/v1/world/edge")
def add_edge(edge: WorldEdge):
    return world_service.add_edge(edge)

@app.get("/v1/world/graph")
def graph():
    return world_service.graph()
