
from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class Chapter:
    title: str
    bullets: List[str] = field(default_factory=list)

@dataclass
class BookSpine:
    title: str
    chapters: List[Chapter] = field(default_factory=list)

def build_tol_spine(seed_topics: List[str]) -> BookSpine:
    chapters = []
    for t in seed_topics:
        chapters.append(Chapter(title=t, bullets=[
            "Key claims",
            "Canonical sources",
            "Neuroscience mapping",
            "Practices & protocols",
            "Falsifiable predictions / measurements"
        ]))
    return BookSpine(title="ToL — Science of Liberation (Draft)", chapters=chapters)
