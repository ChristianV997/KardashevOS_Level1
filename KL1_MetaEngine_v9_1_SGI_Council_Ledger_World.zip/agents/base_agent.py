
class BaseAgent:
    domain = None
    def deliberate(self, ledger, knowledge): raise NotImplementedError
    def conceive(self, context): raise NotImplementedError
    def act(self, pipeline, plan): raise NotImplementedError
    def perceive(self, results): raise NotImplementedError
