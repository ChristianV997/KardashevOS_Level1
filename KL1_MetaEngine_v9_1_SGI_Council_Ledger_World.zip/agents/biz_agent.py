
from agents.base_agent import BaseAgent

class BizAgent(BaseAgent):
    domain = "Biz"
    def deliberate(self, ledger, knowledge):
        return {"ledger": ledger.top("Biz", limit=5), "knowledge": knowledge.recent(limit=10)}
    def conceive(self, context):
        return "Advance Biz: extract actionable opportunities with ROI assumptions and next actions"
    def act(self, pipeline, plan):
        return pipeline.run("market_scan", {"plan": plan})
    def perceive(self, results):
        return {"summary": results, "confidence": 0.70, "signals": {"roi": 0.65}}
