
import yaml
from pipelines.operators import ingest, analyze, simulate, summarize, verify

OPS = {
    "fetch_papers": ingest.fetch_papers,
    "fetch_news": ingest.fetch_news,
    "summarize": summarize.summarize,
    "tag_domains": analyze.tag_domains,
    "analyze_sentiment": analyze.analyze_sentiment,
    "generate_equations": simulate.generate_equations,
    "run_sympy": simulate.run_sympy,
    "verify": verify.verify,
}

class PipelineRunner:
    def __init__(self):
        with open("pipelines/registry.yaml", "r", encoding="utf-8") as f:
            self.registry = yaml.safe_load(f)

    def run(self, pipeline_id, payload):
        ops = self.registry.get(pipeline_id, [])
        data = payload
        trace = []
        for op in ops:
            fn = OPS.get(op)
            if fn is None:
                continue
            data = fn(data)
            trace.append(op)
        data["_trace"] = trace
        return data
