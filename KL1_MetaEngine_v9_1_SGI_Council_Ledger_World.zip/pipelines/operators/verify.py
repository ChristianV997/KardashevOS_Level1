
def verify(data):
    # Placeholder verifier; later: unit tests, theorem checks, citation checks, backtests
    data["verified"] = True
    data["confidence"] = data.get("confidence", 0.6)
    return data
