
def fetch_papers(data):
    # TODO: replace with real connectors (arXiv, PubMed, etc.) via n8n/web ingestors
    return {"papers": [{"title": "placeholder", "source": "arXiv"}], **data}

def fetch_news(data):
    return {"news": [{"title": "placeholder", "source": "web"}], **data}
