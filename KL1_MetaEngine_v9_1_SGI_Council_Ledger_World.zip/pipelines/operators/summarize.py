
def summarize(data):
    data["summary"] = data.get("summary") or "auto-summary placeholder"
    return data
