
def generate_equations(data):
    data["equations"] = ["E=mc^2"]
    return data

def run_sympy(data):
    # TODO: real sympy solve/verify
    data["sympy"] = {"status": "ok"}
    return data
