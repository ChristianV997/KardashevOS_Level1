
def tag_domains(data):
    data["tags"] = list(set((data.get("tags") or []) + ["physics", "neuroscience", "business"]))
    return data

def analyze_sentiment(data):
    data["sentiment"] = "neutral"
    return data
