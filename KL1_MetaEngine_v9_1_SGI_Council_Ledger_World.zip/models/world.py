
from datetime import datetime
from typing import Any, Optional, Literal
from pydantic import BaseModel, Field

WorldState = Literal["active", "suppressed", "snoozed", "resolved"]
EdgeKind = Literal["correlates", "causes", "supports", "contradicts", "depends_on"]

class WorldNode(BaseModel):
    id: str
    kind: str
    title: str
    state: WorldState = "active"
    snooze_until: Optional[datetime] = None
    provenance: dict[str, Any] = Field(default_factory=dict)
    payload: dict[str, Any] = Field(default_factory=dict)

class WorldEdge(BaseModel):
    src: str
    dst: str
    kind: EdgeKind = "correlates"
    weight: float = 0.5
    evidence: dict[str, Any] = Field(default_factory=dict)
