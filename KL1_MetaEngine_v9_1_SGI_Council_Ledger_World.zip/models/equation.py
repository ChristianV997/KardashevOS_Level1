
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field

class Equation(BaseModel):
    id: str
    name: str
    latex: str
    domain: str = "unknown"
    status: str = "candidate"
    gps_score: Optional[float] = Field(default=None, description="Global Priority Score (0–1).")
    notes: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
