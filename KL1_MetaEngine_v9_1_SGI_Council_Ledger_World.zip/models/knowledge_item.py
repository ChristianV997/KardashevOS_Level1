
from datetime import datetime
from typing import Any, Optional, List, Literal
from pydantic import BaseModel, Field

KnowledgeKind = Literal["research", "opportunity", "note", "alert", "dataset", "paper", "news"]

class KnowledgeItem(BaseModel):
    id: str
    kind: KnowledgeKind = "research"
    title: str
    source: str = "unknown"
    url: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    gps_score: Optional[float] = Field(default=None, description="Global Priority Score (0–1).")
    summary: Optional[str] = None
    payload: Optional[dict[str, Any]] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
