# Migration Notes

This v6 bundle does NOT yet:

- Unify databases or schemas across stacks.
- Standardize authentication / authorization.
- Merge duplicated logic (e.g. multiple research scrapers).
- Provide production-ready Docker images or CI/CD.

These are deliberate future steps. The priority of this bundle is:

1. Ensure no work is lost (all stacks bundled).
2. Provide a **single zip** you can store on devices.
3. Give you clear starting points for deeper integration.

Suggested next passes:

- Pick a canonical database (e.g. Postgres) and begin unifying schemas.
- Introduce a single auth provider (JWT / OAuth) and standardize around it.
- Wrap each legacy stack with an API gateway layer for routing, logging, and metrics.
