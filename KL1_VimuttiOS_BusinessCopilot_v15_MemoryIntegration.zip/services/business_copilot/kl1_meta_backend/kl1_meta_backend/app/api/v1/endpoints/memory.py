"""API endpoints for memory management.

This module exposes routes under the ``/api/v1/memory`` namespace to
log events and query them from the short, medium and long‑term
memory. It delegates to the ``memory_engine`` module for actual
storage and retrieval.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body

from kl1_meta_backend.app.services import memory_engine


router = APIRouter(prefix="/memory", tags=["memory"])


@router.post("/log")
def log_event(
    category: str = Body(...),
    data: Dict[str, Any] = Body(...),
) -> Dict[str, str]:
    """Append an event to the memory store."""
    memory_engine.log_event(category=category, data=data)
    return {"status": "logged"}


@router.get("/short-term")
def short_term(n: int = 10) -> List[Dict[str, Any]]:
    """Retrieve the last ``n`` events (short‑term memory)."""
    return memory_engine.get_short_term(n)


@router.get("/medium-term")
def medium_term(n: int = 50) -> List[Dict[str, Any]]:
    """Retrieve the last ``n`` events (medium‑term memory)."""
    return memory_engine.get_medium_term(n)


@router.get("/long-term")
def long_term() -> List[Dict[str, Any]]:
    """Retrieve all events from the memory store (long‑term memory)."""
    return memory_engine.get_long_term()


@router.post("/search")
def search_memory(
    query: str = Body(...),
) -> List[Dict[str, Any]]:
    """Return events whose content matches the given query (case‑insensitive)."""
    return memory_engine.search_memory(query=query)
