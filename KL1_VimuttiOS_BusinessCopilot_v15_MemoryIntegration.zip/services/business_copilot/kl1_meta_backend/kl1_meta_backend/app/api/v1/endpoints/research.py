"""API endpoints for research and opportunity generation.

This module exposes routes under the ``/api/v1/research`` namespace.
The endpoints allow clients to trigger market shift detection,
generate opportunity briefs, score them, and obtain experimental
definitions for testing hypotheses. The implementation delegates to
the ``research_engine`` module.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body

from kl1_meta_backend.app.services import research_engine

router = APIRouter(prefix="/research", tags=["research"])


@router.post("/run")
def run_research(
    top_n: int = Body(5),
) -> Dict[str, Any]:
    """Run a complete research cycle and return shifts and opportunities."""
    shifts = research_engine.generate_market_shifts(top_n=top_n)
    opportunities = research_engine.generate_opportunity_briefs(
        shifts=shifts,
        top_n=top_n,
    )
    return {
        "shifts": shifts,
        "opportunities": opportunities,
    }


@router.get("/shifts")
def get_shifts(
    top_n: int = 5,
) -> List[Dict[str, Any]]:
    """Return the top market shifts detected."""
    return research_engine.generate_market_shifts(top_n=top_n)


@router.post("/opportunities")
def get_opportunities(
    shifts: Optional[List[Dict[str, Any]]] = Body(None),
    frameworks: Optional[List[Dict[str, Any]]] = Body(None),
    top_n: int = Body(10),
) -> List[Dict[str, Any]]:
    """Return opportunity briefs given shifts and frameworks."""
    return research_engine.generate_opportunity_briefs(
        shifts=shifts,
        frameworks=frameworks,
        top_n=top_n,
    )


@router.post("/opportunities/score")
def score_opps(
    opportunities: List[Dict[str, Any]] = Body(...),
    weights: Optional[Dict[str, float]] = Body(None),
) -> List[Dict[str, Any]]:
    """Score and rank opportunities based on heuristic criteria."""
    return research_engine.score_opportunities(
        opportunities=opportunities,
        weights=weights,
    )


@router.post("/experiments")
def create_experiments(
    opportunities: List[Dict[str, Any]] = Body(...),
    period: int = Body(7),
) -> List[Dict[str, Any]]:
    """Generate experiment definitions for opportunities."""
    return research_engine.generate_experiments_for_opportunities(
        opportunities=opportunities,
        period=period,
    )
