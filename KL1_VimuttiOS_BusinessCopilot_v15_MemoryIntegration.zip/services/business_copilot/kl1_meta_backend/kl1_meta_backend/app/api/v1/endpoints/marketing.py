"""API endpoints for marketing automation.

This module exposes routes under the ``/api/v1/marketing`` namespace.
The endpoints delegate to functions in ``marketing_engine`` to
generate campaign briefs, creative assets, rankings, shotlists,
distribution plans, experiments and weekly decisions. Inputs and
outputs are loosely typed dictionaries to maintain flexibility. The
caller is responsible for validating the structure of the objects
passed in.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body

# Use absolute import to avoid issues with relative resolution when packaging
from kl1_meta_backend.app.services import marketing_engine


router = APIRouter(prefix="/marketing", tags=["marketing"])


@router.post("/briefs")
def create_briefs(
    inventory: List[Dict[str, Any]] = Body(...),
    personas: List[Dict[str, Any]] = Body(...),
    offer_defaults: Optional[Dict[str, Any]] = Body(None),
    goal: Optional[str] = Body(None),
) -> List[Dict[str, Any]]:
    """Generate campaign briefs for given inventory and personas."""
    return marketing_engine.generate_campaign_briefs(
        inventory=inventory,
        personas=personas,
        offer_defaults=offer_defaults,
        goal=goal,
    )


@router.post("/creatives/generate")
def generate_creatives(
    ad_brief: Dict[str, Any] = Body(...),
    frameworks: List[str] = Body(...),
    n_variants: int = Body(3),
) -> List[Dict[str, Any]]:
    """Generate creative assets for an ad brief using specified frameworks."""
    return marketing_engine.generate_creatives(
        ad_brief=ad_brief,
        frameworks=frameworks,
        n_variants=n_variants,
    )


@router.post("/creatives/rank")
def rank_creatives(
    creatives: List[Dict[str, Any]] = Body(...),
    persona: Optional[Dict[str, Any]] = Body(None),
    channel: Optional[str] = Body(None),
    constraints: Optional[Dict[str, Any]] = Body(None),
) -> List[Dict[str, Any]]:
    """Rank creative variants based on simple heuristics."""
    return marketing_engine.rank_creatives(
        creatives=creatives,
        persona=persona,
        channel=channel,
        constraints=constraints,
    )


@router.post("/shotlists/expand")
def expand_shotlists(
    creative: Dict[str, Any] = Body(...),
) -> Dict[str, Any]:
    """Expand a creative into a shotlist."""
    return marketing_engine.expand_shotlist(creative=creative)


@router.post("/distribution/plan")
def plan_distribution(
    creative: Dict[str, Any] = Body(...),
    persona: Optional[Dict[str, Any]] = Body(None),
    channels: Optional[List[str]] = Body(None),
) -> Dict[str, Any]:
    """Build a distribution plan for a creative across channels."""
    return marketing_engine.plan_distribution(
        creative=creative,
        persona=persona,
        channels=channels,
    )


@router.post("/experiments/create")
def create_experiments(
    hypothesis: str = Body(...),
    variants: List[Dict[str, Any]] = Body(...),
    metric_targets: Dict[str, float] = Body(...),
    stop_rules: Dict[str, Any] = Body(...),
    winner_rule: Dict[str, Any] = Body(...),
) -> Dict[str, Any]:
    """Create a new experiment definition."""
    return marketing_engine.create_experiment(
        hypothesis=hypothesis,
        variants=variants,
        metric_targets=metric_targets,
        stop_rules=stop_rules,
        winner_rule=winner_rule,
    )


@router.post("/loop/weekly")
def weekly_loop(
    results: List[Dict[str, Any]] = Body(...),
    top_pct: float = Body(0.2),
    bottom_pct: float = Body(0.2),
) -> List[Dict[str, Any]]:
    """Decide next actions based on creative performance results."""
    return marketing_engine.run_weekly_loop(
        results=results,
        top_pct=top_pct,
        bottom_pct=bottom_pct,
    )
