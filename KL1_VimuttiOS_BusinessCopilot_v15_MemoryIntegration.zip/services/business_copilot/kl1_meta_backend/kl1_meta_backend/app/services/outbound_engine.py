from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from ..models.outbound_campaign import OutboundCampaign, OutboundDraft, OutboundMessage
from ..schemas.outbound import OutboundGenerateRequest
from ..services.research_registry import research_registry
from ..services.experiment_registry import experiment_registry
from ..schemas.experiment import ExperimentCreate, ExperimentUpdate
from ..services.outbound_templates import templates, render_vars
from ..services.outbound_registry import outbound_registry


def _lead_from_item(item) -> Dict[str, Any]:
    payload = item.payload or {}
    if isinstance(payload, dict) and isinstance(payload.get("lead"), dict):
        return payload.get("lead", {})
    # Fall back to row
    if isinstance(payload, dict) and isinstance(payload.get("row"), dict):
        return payload.get("row", {})
    return {}


def _opportunity_payload(item) -> Dict[str, Any]:
    payload = item.payload or {}
    if isinstance(payload, dict) and isinstance(payload.get("opportunity"), dict):
        return payload.get("opportunity", {})
    return {}


def _render_subject(subject_tpl: Optional[str], vars: Dict[str, str]) -> Optional[str]:
    if not subject_tpl:
        return None
    s = subject_tpl.format(**vars)
    # cleanup if company empty
    if vars.get("company") == "":
        s = s.replace(" for ", " ").replace(" para ", " ").strip()
    return s


def _render_body(body_tpl: str, vars: Dict[str, str]) -> str:
    b = body_tpl.format(**vars)
    # if no calendar link, remove dangling line
    if not vars.get("calendar_link"):
        b = b.replace("\n{calendar_link}\n", "\n")
        b = b.replace("{calendar_link}", "")
    # if sender missing, try to remove awkward "I'm"
    if not vars.get("sender_name"):
        b = b.replace("I'm ", "").replace("Soy ", "")
    return b.strip()


def _select_lead_items(req: OutboundGenerateRequest) -> List[int]:
    ids: List[int] = []
    if req.lead_ids:
        ids.extend([int(i) for i in req.lead_ids])
    if req.lead_tag:
        tagged = research_registry.list(tag=req.lead_tag, limit=10000)
        ids.extend([i.id for i in tagged])
    # de-dup preserve order
    seen = set()
    out = []
    for i in ids:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out


def generate_campaign(req: OutboundGenerateRequest) -> Tuple[OutboundCampaign, Optional[int]]:
    opp_item = research_registry.get(req.opportunity_id)
    if not opp_item:
        raise ValueError(f"opportunity_id {req.opportunity_id} not found")
    opp = _opportunity_payload(opp_item)

    lead_ids = _select_lead_items(req)
    lead_items = []
    for lid in lead_ids:
        it = research_registry.get(lid)
        if it:
            lead_items.append(it)

    # Create an experiment variant for tracking (optional)
    exp_id: Optional[int] = None
    if req.auto_create_experiment:
        exp = experiment_registry.create(
            ExperimentCreate(
                opportunity_id=req.opportunity_id,
                name=f"Outbound {req.channel} {req.variant}",
                hypothesis="This outbound variant will generate measurable replies/booked calls.",
                test_type="outreach",
                status="running",
                cost_usd=0.0,
                effort_hours=0.0,
                metrics={"outreaches": 0, "replies": 0, "booked_calls": 0},
                notes=f"Generated via OutboundKit; language={req.language}; steps={req.sequence_steps}",
            )
        )
        exp_id = exp.id

    drafts: List[OutboundDraft] = []
    for it in lead_items:
        lead = _lead_from_item(it)
        vars = render_vars(
            language=req.language,
            channel=req.channel,
            lead=lead,
            opportunity=opp,
            sender_name=req.sender_name,
            agency_name=req.agency_name,
            calendar_link=req.calendar_link,
        )
        msgs: List[OutboundMessage] = []
        for step in range(1, req.sequence_steps + 1):
            subj_tpl, body_tpl = templates(req.language, req.channel, step)
            subj = _render_subject(subj_tpl, vars)
            body = _render_body(body_tpl, vars)
            # Lightweight A/B hooks: change the first touch framing.
            # Keeps system template-driven (no LLM) but enables real split testing.
            if step == 1 and isinstance(req.variant, str):
                v = req.variant.strip().lower()
                if v in {"a", "va", "v1a", "testa"}:
                    if subj:
                        subj = ("Quick question: " if req.language == "en" else "Pregunta rápida: ") + subj
                    body = ("Quick question—" if req.language == "en" else "Pregunta rápida—") + "\n" + body
                elif v in {"b", "vb", "v1b", "testb"}:
                    if subj:
                        subj = ("Idea for " if req.language == "en" else "Idea para ") + subj
                    body = ("Idea—" if req.language == "en" else "Idea—") + "\n" + body
            msgs.append(
                OutboundMessage(step_index=step, channel=req.channel, subject=subj, body=body)
            )
        drafts.append(OutboundDraft(lead_id=it.id, lead=lead, messages=msgs))

    cid = outbound_registry.new_id()
    name = f"{req.channel.upper()} {req.language.upper()} {req.variant}"
    campaign = OutboundCampaign(
        id=cid,
        created_at=datetime.utcnow(),
        opportunity_id=req.opportunity_id,
        name=name,
        channel=req.channel,
        language=req.language,
        variant=req.variant,
        lead_ids=[it.id for it in lead_items],
        drafts=drafts,
        experiment_id=exp_id,
    )
    outbound_registry.create(campaign)
    return campaign, exp_id
