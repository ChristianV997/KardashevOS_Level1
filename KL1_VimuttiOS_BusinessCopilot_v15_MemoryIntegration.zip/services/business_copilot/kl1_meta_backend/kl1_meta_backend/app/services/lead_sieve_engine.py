from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List, Tuple

from ..schemas.opportunity import OpportunityPayload, OpportunityFeatures
from ..schemas.research_item import ResearchItemUpdate
from ..services.research_registry import research_registry
from ..services.opportunity_engine import create_opportunity_item


LEAD_GROUP_FIELDS = ["industry", "category", "niche", "service", "vertical"]


def _lead_from_item(item) -> Dict[str, Any]:
    payload = item.payload or {}
    if isinstance(payload, dict) and isinstance(payload.get("lead"), dict):
        return payload.get("lead", {})
    if isinstance(payload, dict) and isinstance(payload.get("row"), dict):
        return payload.get("row", {})
    return {}


def _norm(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _extract_group_value(lead: Dict[str, Any], field: str) -> str:
    # direct
    v = _norm(lead.get(field))
    if v:
        return v
    # fallbacks
    for alt in LEAD_GROUP_FIELDS:
        v = _norm(lead.get(alt))
        if v:
            return v
    return "general"


def _reachability(leads: List[Dict[str, Any]]) -> float:
    if not leads:
        return 0.0
    good = 0
    for l in leads:
        for k in ["email", "phone", "website", "url", "instagram", "facebook", "linkedin"]:
            if _norm(l.get(k)):
                good += 1
                break
    return max(0.0, min(1.0, good / max(1, len(leads))))


def _budget_proxy(leads: List[Dict[str, Any]]) -> float:
    """Heuristic budget proxy.

    Uses employees/company_size/revenue if present; otherwise returns a conservative prior.
    """
    if not leads:
        return 0.55
    vals: List[int] = []
    for l in leads:
        for k in ["employees", "employee_count", "company_size", "revenue", "annual_revenue"]:
            v = l.get(k)
            if v is None:
                continue
            try:
                s = str(v)
                digits = "".join(ch for ch in s if ch.isdigit())
                if digits:
                    vals.append(int(digits))
                    break
            except Exception:
                continue
    if not vals:
        return 0.55

    vals.sort()
    med = vals[len(vals) // 2]
    if med >= 200:
        return 0.85
    if med >= 50:
        return 0.75
    if med >= 10:
        return 0.65
    return 0.55


def generate_opportunities_from_leads(
    *,
    lead_tag: str,
    group_field: str = "industry",
    min_group_size: int = 5,
    source: str = "lead_sieve",
    base_tags: List[str] | None = None,
    default_offer_tier: str = "A",
) -> List[Tuple[str, int, float]]:
    """Group a batch of lead items and create starter opportunities.

    Returns: list of tuples (niche, opportunity_item_id, gps_score)
    """
    base_tags = base_tags or ["auto", "lead_sieve"]
    items = research_registry.list(tag=lead_tag, limit=10000)
    if not items:
        return []

    # Prefer items explicitly tagged as leads via payload._meta.type
    lead_items = []
    for it in items:
        payload = it.payload or {}
        meta = payload.get("_meta") if isinstance(payload, dict) else None
        if isinstance(meta, dict) and meta.get("type") == "lead":
            lead_items.append(it)
    if not lead_items:
        lead_items = items

    grouped_leads: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    grouped_ids: Dict[str, List[int]] = defaultdict(list)

    for it in lead_items:
        lead = _lead_from_item(it)
        niche = _extract_group_value(lead, group_field)
        grouped_leads[niche].append(lead)
        grouped_ids[niche].append(it.id)

    created: List[Tuple[str, int, float]] = []
    for niche, leads in grouped_leads.items():
        if len(leads) < min_group_size:
            continue

        reach = _reachability(leads)
        budget = _budget_proxy(leads)

        features = OpportunityFeatures(
            pain=0.65,
            budget=budget,
            reachability=reach,
            speed=0.85,
            fulfillment_fit=0.80,
            moat=0.45,
            risk=0.15,
            load=0.25,
        )

        opp = OpportunityPayload(
            niche=str(niche).lower().replace(" ", "_")[:40] or "general",
            offer_tier=default_offer_tier,
            name=f"{niche} Revenue Ops Quickstart",
            problem=f"{niche}: lead capture + follow-up + booking leakage.",
            proposed_offer="Install lead capture + follow-up + booking automation in 7–14 days; track KPIs weekly.",
            features=features,
            weights=None,
            gps_score=None,
        )

        title = f"{niche}: Revenue Ops Quickstart"
        tags = list(dict.fromkeys(base_tags + [lead_tag, f"lead_group:{group_field}"]))
        summary = (
            f"Auto-generated from {len(leads)} leads tagged {lead_tag}. "
            f"Reachability={reach:.2f}, budget_proxy={budget:.2f}."
        )

        item = create_opportunity_item(
            title=title,
            source=source,
            url=None,
            tags=tags,
            summary=summary,
            opportunity=opp,
        )

        # Add provenance without breaking the opportunity payload schema.
        payload = item.payload or {}
        if isinstance(payload, dict):
            payload["lead_sieve"] = {
                "lead_tag": lead_tag,
                "group_field": group_field,
                "lead_count": len(leads),
                "lead_ids_sample": grouped_ids[niche][:50],
            }
            updated = research_registry.update(item.id, ResearchItemUpdate(payload=payload))
            if updated:
                item = updated

        created.append((str(niche), item.id, float(item.gps_score or 0.0)))

    # Highest GPS first
    created.sort(key=lambda x: x[2], reverse=True)
    return created
