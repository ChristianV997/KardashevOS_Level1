"""Research and opportunity engine.

This module provides functions to synthesize market signals,
frameworks from the learning spine and macroeconomic waves into
actionable insights and opportunity briefs. It serves as the bridge
between raw data (e.g. global time series, learning frameworks)
and high level business proposals.

The functions here are deliberately simplistic. In a real
implementation you would integrate external data sources and
sophisticated models. For the purposes of this code base they
aggregate existing internal artefacts (waves and frameworks) and
produce structured outputs that can be returned via the API.
"""

from __future__ import annotations

from typing import List, Dict, Any

from .global_engine import compute_global_waves
from .learning_engine import compute_learning_frameworks


def generate_market_shifts(
    timeseries: Dict[str, List[float]] | None = None,
    top_n: int = 5,
) -> List[Dict[str, Any]]:
    """Generate a list of significant market shifts.

    If ``timeseries`` is provided it should be a mapping from series
    names to historical values. Otherwise this function will call
    ``compute_global_waves()`` to detect waves based on the global
    timeseries store. Each shift contains the name of the series,
    the percentage change, and a category inferred from the series name.

    Parameters
    ----------
    timeseries: dict, optional
        Timeseries data to analyse. Keys are series names and values are
        lists of numeric values.
    top_n: int
        Maximum number of shifts to return.

    Returns
    -------
    list of dict
        List of market shifts sorted by absolute change descending.
    """
    # Use compute_global_waves if timeseries not provided
    waves_result = compute_global_waves(top_n=top_n)
    shifts: List[Dict[str, Any]] = []
    for wave in waves_result.get("waves", []):
        name = wave.get("name")
        change = wave.get("delta")
        # infer category from name
        category = "macro"
        lname = name.lower() if isinstance(name, str) else ""
        if any(key in lname for key in ["cpi", "inflation"]):
            category = "inflation"
        elif any(key in lname for key in ["rate", "yield"]):
            category = "rates"
        elif any(key in lname for key in ["spx", "equity", "stock"]):
            category = "equities"
        shifts.append({
            "series": name,
            "change": change,
            "category": category,
        })
    # sort by absolute change
    shifts.sort(key=lambda x: abs(x.get("change", 0)), reverse=True)
    return shifts[:top_n]


def generate_opportunity_briefs(
    shifts: List[Dict[str, Any]] | None = None,
    frameworks: List[Dict[str, Any]] | None = None,
    top_n: int = 10,
) -> List[Dict[str, Any]]:
    """Create opportunity briefs based on market shifts and learning frameworks.

    Each brief combines a macro shift with one or more learning
    frameworks. The brief suggests a potential business model,
    defines the target segment, the offering, the channel and a set
    of recommended actions. This is a simplistic heuristic: a real
    implementation could use a scoring model based on financial
    projections and product/market fit.

    Parameters
    ----------
    shifts: list of dict, optional
        The market shifts to base the opportunities on. If omitted,
        ``generate_market_shifts`` will be called.
    frameworks: list of dict, optional
        Frameworks extracted by the learning engine. If omitted,
        ``compute_learning_frameworks`` will be called and its result
        used to build the mapping.
    top_n: int
        Maximum number of opportunities to return.

    Returns
    -------
    list of dict
        A list of opportunity briefs with descriptive information.
    """
    if shifts is None:
        shifts = generate_market_shifts()
    # flatten frameworks
    if frameworks is None:
        fw_res = compute_learning_frameworks(top_n=50)
        frameworks = fw_res.get("frameworks", [])
    # group frameworks by category inferred from title
    fw_map: Dict[str, List[Dict[str, Any]]] = {}
    for fw in frameworks:
        title = fw.get("title", "").lower()
        if "lean" in title or "startup" in title:
            key = "startup"
        elif "ocean" in title or "value" in title:
            key = "strategy"
        elif "profit" in title or "finanzas" in title:
            key = "finance"
        elif "habito" in title or "hábito" in title:
            key = "productivity"
        else:
            key = "general"
        fw_map.setdefault(key, []).append(fw)
    opportunities: List[Dict[str, Any]] = []
    for shift in shifts:
        category = shift.get("category", "macro")
        # choose frameworks relevant to this category
        if category == "inflation" or category == "rates":
            relevant_fws = fw_map.get("finance", [])
        elif category == "equities":
            relevant_fws = fw_map.get("strategy", [])
        else:
            relevant_fws = fw_map.get("startup", []) + fw_map.get("productivity", [])
        # take up to 2 frameworks
        selected = relevant_fws[:2] if relevant_fws else fw_map.get("general", [])[:2]
        # propose a business model
        model = "service" if category in {"inflation", "rates"} else "product"
        opportunity = {
            "market_shift": shift,
            "frameworks": selected,
            "model": model,
            "segment": "aspirational" if category == "equities" else "general",
            "offer": "Consultoría financiera" if model == "service" else "Producto digital",
            "channel": "digital",  # as a default, digital channels
            "actions": [
                "Desarrollar MVP en 2 semanas",
                "Validar demanda con encuestas y preventas",
                "Implementar flujo de caja Profit First",
            ],
        }
        opportunities.append(opportunity)
    # order by absolute change
    opportunities.sort(key=lambda x: abs(x["market_shift"].get("change", 0)), reverse=True)
    return opportunities[:top_n]


def score_opportunities(
    opportunities: List[Dict[str, Any]],
    weights: Dict[str, float] | None = None,
) -> List[Dict[str, Any]]:
    """Score and rank opportunities based on heuristic criteria.

    Each opportunity receives a score computed from tailwind (size of
    market shift), number of frameworks used and a simple risk factor
    derived from the model type. You can adjust weights to favour
    different factors.

    Returns the same list sorted by descending score.
    """
    if weights is None:
        weights = {
            "tailwind": 0.5,
            "frameworks": 0.3,
            "risk": -0.2,
        }
    scored = []
    for opp in opportunities:
        shift_change = abs(opp["market_shift"].get("change", 0))
        n_fw = len(opp.get("frameworks", []))
        # risk factor: product models carry higher risk than services in this simplistic model
        risk = 1.0 if opp.get("model") == "product" else 0.5
        score = (
            weights.get("tailwind", 0) * shift_change
            + weights.get("frameworks", 0) * n_fw
            + weights.get("risk", 0) * risk
        )
        opp_with_score = opp.copy()
        opp_with_score["score"] = score
        scored.append(opp_with_score)
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored


def generate_experiments_for_opportunities(
    opportunities: List[Dict[str, Any]],
    period: int = 7,
) -> List[Dict[str, Any]]:
    """Create test plans for the given opportunities.

    Each plan includes a hypothesis, basic variants description and
    target metrics for a trial period (e.g. 7 days). In this
    simplified example, we assign random target values and minimal
    stop/winner rules.

    Returns
    -------
    list of dict
        A list of experiment specifications for each opportunity.
    """
    experiments: List[Dict[str, Any]] = []
    for opp in opportunities:
        hypothesis = (
            f"La oportunidad '{opp['offer']}' basada en '{opp['market_shift']['series']}' "
            f"será rentable en {period} días"
        )
        variants = [
            {
                "name": "propuesta_principal",
                "offer": opp["offer"],
                "channel": opp["channel"],
            },
            {
                "name": "version_alternativa",
                "offer": opp["offer"] + " beta",
                "channel": opp["channel"],
            },
        ]
        experiment = {
            "hypothesis": hypothesis,
            "variants": variants,
            "metric_targets": {"CPA": 50.0, "CTR": 0.02},
            "stop_rules": {"max_days": period, "min_impressions": 1000},
            "winner_rule": {"metric": "CPA", "direction": "min"},
        }
        experiments.append(experiment)
    return experiments
