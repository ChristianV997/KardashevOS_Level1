"""Memory engine.

This module implements simple in-process memory management for the
Business Copilot OS. It provides functions to log events and
retrieve them as short‑term, medium‑term and long‑term memory. The
memory store is backed by a JSON Lines file whose location can be
configured via the ``KL1_MEMORY_STORE`` environment variable. Each
event is stored as a JSON object with a timestamp, category and
payload.

The memory system is deliberately lightweight; it is not intended to
replace a full database or knowledge graph. Instead it offers
persistent storage for recent events to enable the OS to recall what
has been processed previously and avoid redundant work or token
waste. Clients can query the memory store through the API to build
higher‑level features such as summarisation or attentional focus.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

_DEFAULT_MEMORY_STORE = os.environ.get(
    "KL1_MEMORY_STORE",
    os.path.join(os.path.dirname(__file__), "..", "data", "memory_store.jsonl"),
)


def _ensure_store_exists(path: str) -> None:
    """Ensure the memory store file and its directory exist."""
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8"):
            pass


def log_event(category: str, data: Dict[str, Any], path: Optional[str] = None) -> None:
    """Append an event to the memory store.

    Each event is stored with a timestamp in ISO 8601 format, the
    specified category and the provided data. If the file does not
    exist, it will be created. The caller should handle any
    sensitive information appropriately before logging.
    """
    store_path = path or _DEFAULT_MEMORY_STORE
    _ensure_store_exists(store_path)
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "category": category,
        "data": data,
    }
    with open(store_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _read_events(path: Optional[str] = None) -> List[Dict[str, Any]]:
    store_path = path or _DEFAULT_MEMORY_STORE
    if not os.path.exists(store_path):
        return []
    events: List[Dict[str, Any]] = []
    with open(store_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return events


def get_short_term(n: int = 10, path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return the last ``n`` events from memory (short‑term memory)."""
    events = _read_events(path)
    return events[-n:]


def get_medium_term(n: int = 50, path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return the last ``n`` events (medium‑term memory)."""
    events = _read_events(path)
    return events[-n:]


def get_long_term(path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return all events (long‑term memory)."""
    return _read_events(path)


def search_memory(query: str, path: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return events whose category or data stringified match the query.

    The search is case‑insensitive and performs a simple substring
    match on the JSON representation of the event.
    """
    query_lower = query.lower()
    events = _read_events(path)
    filtered = []
    for e in events:
        blob = json.dumps(e, ensure_ascii=False).lower()
        if query_lower in blob:
            filtered.append(e)
    return filtered
