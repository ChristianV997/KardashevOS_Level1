"""Marketing automation engine.

This module contains helper functions to generate advertising briefs,
creative assets, ranking heuristics and distribution plans based on
internal data structures. The goal of this engine is to provide a
lightweight abstraction over the underlying learning and opportunity
engines so that callers can request "ready to shoot" marketing
materials without writing prompts in plain text.

The design is intentionally minimal – the functions here return
structured Python data (dicts and lists) which can later be serialized
to JSON by the API layer. These objects are not persisted to disk by
default; they are meant to be consumed immediately by callers. If you
need persistence or further customization you can extend this module
with your own storage backend.

All functions accept simple primitive parameters and return Python
objects. They should not perform any network access or external API
calls; instead they operate on the information provided by the caller.
"""

from __future__ import annotations

from typing import Dict, List, Any, Iterable


def generate_campaign_briefs(
    inventory: List[Dict[str, Any]],
    personas: List[Dict[str, Any]],
    offer_defaults: Dict[str, Any] | None = None,
    goal: str | None = None,
) -> List[Dict[str, Any]]:
    """Create high level campaign briefs based on inventory and personas.

    A campaign brief groups a set of products (SKUs) with one or more
    target personas and includes a rough outline of angles, objections
    and messaging. It does not contain actual copy – this is
    generated later via generate_creatives().

    Parameters
    ----------
    inventory: list of dict
        List of SKU dictionaries. Each dict can contain fields like
        ``sku``, ``marca``, ``modelo``, ``categoria``, ``condicion`` and
        any other metadata relevant to the product.
    personas: list of dict
        List of persona dictionaries. Each dict may include a
        ``segmento`` key (e.g. "aspiracional", "vip"), triggers and
        objections to inform creative angles.
    offer_defaults: dict, optional
        Default fields for offers (e.g. installments, bundles).
    goal: str, optional
        The primary marketing objective (e.g. "sales", "leads").

    Returns
    -------
    list of dict
        A list of campaign briefs. Each brief contains a unique
        identifier, the list of SKUs targeted, the personas, the goal
        and a list of suggested angles.
    """
    briefs: List[Dict[str, Any]] = []
    for idx, sku in enumerate(inventory):
        for persona in personas:
            brief = {
                "id": f"brief_{idx}_{persona.get('segmento', 'unknown')}",
                "skus": [sku],
                "persona": persona,
                "goal": goal or "sales",
                "angles": [
                    "autenticidad",
                    "precio_inteligente",
                    "historia",
                    "escasez_real",
                    "inversion_licuida",
                ],
                "offer_defaults": offer_defaults or {},
            }
            briefs.append(brief)
    return briefs


def generate_creatives(
    ad_brief: Dict[str, Any],
    frameworks: Iterable[str],
    n_variants: int = 3,
) -> List[Dict[str, Any]]:
    """Generate creative variants for a given ad brief.

    This function uses a set of pre-defined copywriting frameworks
    (such as AIDA, PAS, BAB, SSS, 4P) to produce multiple creative
    outlines. Each variant includes the framework name, a hook,
    a proof line, an offer line and a call-to-action.

    Parameters
    ----------
    ad_brief: dict
        The brief produced by generate_campaign_briefs() containing
        persona, product and angle information.
    frameworks: iterable of str
        Names of copywriting frameworks to use for generation.
    n_variants: int
        Number of variants to produce per framework.

    Returns
    -------
    list of dict
        A list of creative assets. Each contains a framework,
        persona, angle and the lines needed to produce a video or
        social ad.
    """
    creatives: List[Dict[str, Any]] = []
    persona = ad_brief.get("persona", {})
    persona_segment = persona.get("segmento", "generico")
    sku = ad_brief.get("skus", [{}])[0]
    model = sku.get("modelo") or sku.get("sku") or "producto"
    for framework in frameworks:
        for i in range(n_variants):
            hook = f"¿Cómo {model} puede ayudarte hoy?"
            if i == 1:
                hook = f"3 razones para elegir {model}"
            elif i == 2:
                hook = f"¿Sabías esto de {model}?"
            creative = {
                "framework": framework,
                "persona": persona_segment,
                "angle": ad_brief.get("angles", ["autenticidad"])[0],
                "hook": hook,
                "proof": f"Certificado y garantía disponibles para {model}",
                "offer": f"Precio especial disponible – pregunta por {model}",
                "cta": "Envíanos un DM para más detalles",
            }
            creatives.append(creative)
    return creatives


def rank_creatives(
    creatives: List[Dict[str, Any]],
    persona: Dict[str, Any] | None = None,
    channel: str | None = None,
    constraints: Dict[str, Any] | None = None,
) -> List[Dict[str, Any]]:
    """Rank creative variants based on simple heuristics.

    The ranking algorithm assigns a score to each creative. Currently
    the heuristics are very naive: for demonstration purposes the
    function scores higher if the hook length is short and the angle
    matches the persona interest. In practice you would integrate
    campaign performance metrics here.

    Returns the creatives sorted by descending score.
    """
    ranked = []
    persona_segment = persona.get("segmento") if persona else None
    preferred_angles = []
    if persona_segment == "aspiracional":
        preferred_angles = ["precio_inteligente", "autenticidad"]
    elif persona_segment == "vip":
        preferred_angles = ["exclusividad", "acceso"]
    elif persona_segment == "coleccionista":
        preferred_angles = ["historia", "autenticidad"]
    else:
        preferred_angles = ["autenticidad"]
    for creative in creatives:
        score = 0
        # shorter hooks are considered stronger
        score += max(0, 30 - len(creative.get("hook", "")))
        # match angle
        if creative.get("angle") in preferred_angles:
            score += 20
        # simple channel preference: favour TikTok style frameworks
        if channel and channel.lower() == "tiktok" and creative.get("framework").lower() in {"aida", "pas"}:
            score += 10
        creative_with_score = creative.copy()
        creative_with_score["score"] = score
        ranked.append(creative_with_score)
    ranked.sort(key=lambda x: x["score"], reverse=True)
    return ranked


def expand_shotlist(creative: Dict[str, Any]) -> Dict[str, Any]:
    """Expand a creative into a shotlist for video production.

    The returned dictionary includes a list of shots with duration and
    suggested content. This is a very simple implementation to show
    how a structured creative can become a detailed plan.
    """
    hook = creative.get("hook", "")
    proof = creative.get("proof", "")
    offer = creative.get("offer", "")
    cta = creative.get("cta", "")
    shots = [
        {"start": 0, "end": 3, "description": hook},
        {"start": 3, "end": 10, "description": proof},
        {"start": 10, "end": 15, "description": offer},
        {"start": 15, "end": 20, "description": cta},
    ]
    return {
        "creative": creative,
        "shots": shots,
        "overlay": creative.get("overlay", {}),
    }


def plan_distribution(
    creative: Dict[str, Any],
    persona: Dict[str, Any] | None = None,
    channels: List[str] | None = None,
) -> Dict[str, Any]:
    """Build a distribution plan for a creative across channels.

    The plan outlines the sequence of phases (organic, paid, retarget,
    close) and recommended settings for each phase. This is a simple
    stub; in a real implementation you would integrate analytics to
    refine the plan.
    """
    if channels is None:
        channels = ["tiktok", "instagram"]
    plan = []
    for channel in channels:
        plan.append({
            "channel": channel,
            "phases": [
                {
                    "name": "organic",
                    "description": "Publicar en el feed y medir engagement inicial"
                },
                {
                    "name": "prospecting",
                    "description": "Impulsar con publicidad para alcanzar nuevas audiencias"
                },
                {
                    "name": "retargeting",
                    "description": "Reimpactar a quienes interactuaron con versiones cortas"
                },
                {
                    "name": "close",
                    "description": "Anuncios de cierre con oferta limitada y CTA directo"
                },
            ],
        })
    return {
        "creative": creative,
        "distribution": plan,
    }


def create_experiment(
    hypothesis: str,
    variants: List[Dict[str, Any]],
    metric_targets: Dict[str, float],
    stop_rules: Dict[str, Any],
    winner_rule: Dict[str, Any],
) -> Dict[str, Any]:
    """Create an A/B/C experiment definition.

    Parameters
    ----------
    hypothesis: str
        The hypothesis being tested.
    variants: list of dict
        The creative variants to test.
    metric_targets: dict
        Target values for key metrics (e.g. CTR, CPA).
    stop_rules: dict
        Conditions to stop the experiment (e.g. minimum impressions).
    winner_rule: dict
        Criteria to declare a winner (e.g. top performer on ROAS).

    Returns
    -------
    dict
        An experiment specification with metadata.
    """
    return {
        "hypothesis": hypothesis,
        "variants": variants,
        "metric_targets": metric_targets,
        "stop_rules": stop_rules,
        "winner_rule": winner_rule,
    }


def run_weekly_loop(
    results: List[Dict[str, Any]],
    top_pct: float = 0.2,
    bottom_pct: float = 0.2,
) -> List[Dict[str, Any]]:
    """Decide next actions based on creative performance results.

    The function expects a list of dictionaries, each containing at
    least a `score` or key metrics. It returns a list of decisions
    indicating whether to duplicate (scale up), iterate (tweak) or
    pause a creative.
    """
    if not results:
        return []
    # sort by score descending
    sorted_results = sorted(results, key=lambda x: x.get("score", 0), reverse=True)
    n = len(sorted_results)
    top_cutoff = int(n * top_pct)
    bottom_cutoff = int(n * bottom_pct)
    decisions = []
    for idx, item in enumerate(sorted_results):
        if idx < top_cutoff:
            action = "duplicate"
        elif idx >= n - bottom_cutoff:
            action = "pause"
        else:
            action = "iterate"
        decisions.append({
            "creative": item,
            "action": action,
        })
    return decisions
