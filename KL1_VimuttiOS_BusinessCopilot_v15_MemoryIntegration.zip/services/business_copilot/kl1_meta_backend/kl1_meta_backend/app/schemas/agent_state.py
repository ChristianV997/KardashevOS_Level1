from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field


class AgentStateBase(BaseModel):
    role: Optional[str] = None
    config: dict[str, Any] = Field(default_factory=dict)


class AgentStateCreate(AgentStateBase):
    name: str


class AgentStateUpdate(BaseModel):
    role: Optional[str] = None
    config: Optional[dict[str, Any]] = None


class AgentStateRead(AgentStateBase):
    name: str
    last_updated: datetime
