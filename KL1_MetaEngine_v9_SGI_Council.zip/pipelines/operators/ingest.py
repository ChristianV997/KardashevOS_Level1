
def fetch_papers(data):
    return {"papers": ["paper_a", "paper_b"], **data}

def fetch_news(data):
    return {"news": ["item1", "item2"], **data}
