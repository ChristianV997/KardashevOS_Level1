
def summarize(data):
    data["summary"] = "concise summary"
    return data
