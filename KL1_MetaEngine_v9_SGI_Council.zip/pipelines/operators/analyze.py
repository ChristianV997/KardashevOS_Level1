
def tag_domains(data):
    data["tags"] = ["physics", "neuroscience"]
    return data

def analyze_sentiment(data):
    data["sentiment"] = "positive"
    return data
