
import yaml
from pipelines.operators import ingest, analyze, simulate, summarize

OPS = {
    "fetch_papers": ingest.fetch_papers,
    "fetch_news": ingest.fetch_news,
    "summarize": summarize.summarize,
    "tag_domains": analyze.tag_domains,
    "generate_equations": simulate.generate_equations,
    "run_sympy": simulate.run_sympy,
    "plot_results": simulate.plot_results,
    "analyze_sentiment": analyze.analyze_sentiment,
}

class PipelineRunner:
    def __init__(self):
        with open("pipelines/registry.yaml") as f:
            self.registry = yaml.safe_load(f)

    def run(self, pipeline_id, payload):
        ops = self.registry.get(pipeline_id, [])
        data = payload
        for op in ops:
            fn = OPS.get(op)
            if fn:
                data = fn(data)
        return data
