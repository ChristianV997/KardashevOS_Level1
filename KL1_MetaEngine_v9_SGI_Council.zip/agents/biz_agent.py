
from agents.base_agent import BaseAgent

class BizAgent(BaseAgent):
    domain = "Biz"
    def deliberate(self, ledger):
        return ledger.top_insights("Biz", limit=5)
    def conceive(self, context):
        return "Identify market opportunities via trend synthesis"
    def act(self, pipeline, plan):
        return pipeline.run("market_scan", {"plan": plan})
    def perceive(self, results):
        return {"summary": results, "confidence": 0.70}
