
from agents.base_agent import BaseAgent

class ToLAgent(BaseAgent):
    domain = "ToL"
    def deliberate(self, ledger):
        return ledger.top_insights("ToL", limit=5)
    def conceive(self, context):
        return "Map Theravada stages to neuroscience correlates"
    def act(self, pipeline, plan):
        return pipeline.run("literature_ingest", {"plan": plan})
    def perceive(self, results):
        return {"summary": results, "confidence": 0.68}
