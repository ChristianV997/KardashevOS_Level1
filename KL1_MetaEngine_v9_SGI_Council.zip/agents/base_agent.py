
class BaseAgent:
    domain = None
    def deliberate(self, ledger): raise NotImplementedError
    def conceive(self, context): raise NotImplementedError
    def act(self, pipeline, plan): raise NotImplementedError
    def perceive(self, results): raise NotImplementedError
