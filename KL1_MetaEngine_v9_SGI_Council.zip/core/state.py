
class SharedState:
    def __init__(self):
        self.memory = {}
        self.context = {}
        self.metrics = {}

STATE = SharedState()
