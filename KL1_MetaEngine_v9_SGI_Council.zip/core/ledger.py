
class Ledger:
    def __init__(self):
        self.entries = []

    def add(self, domain, hypothesis, evidence, score):
        self.entries.append({
            "domain": domain,
            "hypothesis": hypothesis,
            "evidence": evidence,
            "confidence": float(score)
        })

    def top_insights(self, domain=None, limit=10):
        rows = self.entries if domain is None else [e for e in self.entries if e["domain"] == domain]
        return sorted(rows, key=lambda x: x["confidence"], reverse=True)[:limit]

LEDGER = Ledger()
