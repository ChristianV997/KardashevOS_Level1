
from agents.toe_agent import ToEAgent
from agents.tol_agent import ToLAgent
from agents.biz_agent import BizAgent
from core.ledger import LEDGER

class Council:
    def __init__(self):
        self.agents = [ToEAgent(), ToLAgent(), BizAgent()]

    def run_cycle(self, pipeline):
        outputs = []
        for agent in self.agents:
            context = agent.deliberate(LEDGER)
            plan = agent.conceive(context)
            result = agent.act(pipeline, plan)
            insight = agent.perceive(result)
            LEDGER.add(agent.domain, plan, result, insight.get("confidence", 0.5))
            outputs.append({"domain": agent.domain, **insight})
        return outputs
