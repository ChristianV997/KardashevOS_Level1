
from core.council import Council
from pipelines.runner import PipelineRunner

def run_once():
    runner = PipelineRunner()
    council = Council()
    return council.run_cycle(runner)

if __name__ == "__main__":
    print(run_once())
