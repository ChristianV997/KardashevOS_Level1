
def next_run_plan(ledger, threshold=0.6, limit=10):
    return [e for e in ledger.top_insights() if e["confidence"] >= threshold][:limit]
