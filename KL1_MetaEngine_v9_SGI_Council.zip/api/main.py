
from fastapi import FastAPI
from core.engine import run_once
from core.planner import next_run_plan
from core.ledger import LEDGER

app = FastAPI()

@app.post("/v1/council/cycle")
def council_cycle():
    return run_once()

@app.get("/v1/next-run")
def next_run():
    return next_run_plan(LEDGER)
