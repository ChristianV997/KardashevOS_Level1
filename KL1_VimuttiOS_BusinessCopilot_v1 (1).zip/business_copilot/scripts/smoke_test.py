"""Minimal smoke test for Business Copilot API.

Run:
  PYTHONPATH=services/business_copilot/kl1_meta_backend python scripts/smoke_test.py
"""

from fastapi.testclient import TestClient

# Import the app from the packaged service
from kl1_meta_backend.app.main import app


def main() -> None:
    c = TestClient(app)
    assert c.get("/health").status_code == 200

    # Create opportunity
    opp_payload = {
        "title": "Dental: missed-call recovery",
        "summary": "Automate missed call follow-up to recover leads.",
        "tags": ["revops"],
        "opportunity": {
            "niche": "dental",
            "offer_tier": "A",
            "name": "Missed-call Recovery",
            "problem": "Leads vanish when phones aren't answered.",
            "proposed_offer": "Install missed-call SMS + intake + booking automation in 7 days.",
            "features": {
                "pain": 0.9,
                "budget": 0.8,
                "reachability": 0.7,
                "speed": 0.9,
                "fulfillment_fit": 0.8,
                "moat": 0.6,
                "risk": 0.1,
                "load": 0.3,
            },
        },
    }
    r = c.post("/api/v1/opportunities/", json=opp_payload)
    assert r.status_code in (200, 201), r.text
    opp_id = r.json()["id"]

    # Ingest a lead
    lead_text = {
        "source": "manual",
        "title": "Lead: Smile Studio",
        "text": "name=Smile Studio; email=owner@smilestudio.example; niche=dental",
        "tags": ["LEADS_DENTAL_SAMPLE"],
        "item_type": "lead",
    }
    r = c.post("/api/v1/market_scout/ingest/text", json=lead_text)
    assert r.status_code == 200, r.text

    # Generate outbound campaign (creates experiment)
    gen = {
        "opportunity_id": opp_id,
        "lead_tag": "LEADS_DENTAL_SAMPLE",
        "channel": "email",
        "language": "en",
        "sequence_steps": 3,
        "variant": "v1",
        "sender_name": "Christian",
        "agency_name": "KL1 Growth Ops",
        "calendar_link": "https://calendly.com/your-link",
        "auto_create_experiment": True,
    }
    r = c.post("/api/v1/outbound/generate", json=gen)
    assert r.status_code == 200, r.text
    camp_id = r.json()["campaign_id"]
    exp_id = r.json().get("experiment_id")
    assert exp_id is not None

    # Log some results
    r = c.post(f"/api/v1/outbound/campaigns/{camp_id}/log", json={"outreaches": 100, "replies": 6, "booked_calls": 2})
    assert r.status_code == 200, r.text

    # Complete experiment (triggers adaptation)
    r = c.post(f"/api/v1/experiments/{exp_id}/complete")
    assert r.status_code == 200, r.text

    # Run evals
    r = c.get("/api/v1/evals/run")
    assert r.status_code == 200, r.text
    assert r.json().get("passed") is True

    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
