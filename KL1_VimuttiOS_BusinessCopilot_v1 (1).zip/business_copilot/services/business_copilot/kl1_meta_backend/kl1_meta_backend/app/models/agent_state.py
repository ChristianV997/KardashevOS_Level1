from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field


class AgentState(BaseModel):
    name: str
    role: Optional[str] = None
    config: dict[str, Any] = Field(default_factory=dict)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
