from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class OutboundMessage(BaseModel):
    step_index: int = Field(..., ge=1)
    channel: str
    subject: Optional[str] = None
    body: str


class OutboundDraft(BaseModel):
    lead_id: int
    lead: Dict[str, Any] = Field(default_factory=dict)
    messages: List[OutboundMessage] = Field(default_factory=list)


class OutboundCampaign(BaseModel):
    id: int
    created_at: datetime
    opportunity_id: int
    name: str
    channel: str
    language: str = "en"
    variant: str = "v1"
    lead_ids: List[int] = Field(default_factory=list)
    drafts: List[OutboundDraft] = Field(default_factory=list)
    experiment_id: Optional[int] = None
