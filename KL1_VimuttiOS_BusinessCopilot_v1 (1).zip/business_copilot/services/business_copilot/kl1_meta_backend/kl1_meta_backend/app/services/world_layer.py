from typing import Dict, List
from ..models.world_layer import WorldNode, WorldEdge


class WorldLayerService:
    def __init__(self) -> None:
        self._nodes: Dict[str, WorldNode] = {}
        self._edges: List[WorldEdge] = []

    def upsert_node(self, node: WorldNode) -> WorldNode:
        self._nodes[node.id] = node
        return node

    def add_edge(self, edge: WorldEdge) -> WorldEdge:
        self._edges.append(edge)
        return edge

    def get_graph(self) -> tuple[list[WorldNode], list[WorldEdge]]:
        return list(self._nodes.values()), list(self._edges)


world_layer_service = WorldLayerService()
