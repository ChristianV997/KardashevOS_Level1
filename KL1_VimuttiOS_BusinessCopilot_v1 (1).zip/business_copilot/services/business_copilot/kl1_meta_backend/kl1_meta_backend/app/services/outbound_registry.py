from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..models.outbound_campaign import OutboundCampaign
from ..schemas.outbound import OutboundGenerateRequest


def _default_store_path() -> Path:
    app_dir = Path(__file__).resolve().parents[1]
    data_dir = app_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "outbound_campaigns.json"


class OutboundRegistry:
    """In-memory outbound campaigns with JSON persistence.

    A campaign is a generated set of message drafts for a batch of leads.
    We don't send messages here (no SMTP/Twilio); we generate + export + log outcomes.
    """

    def __init__(self, store_path: Optional[Path] = None) -> None:
        self._items: Dict[int, OutboundCampaign] = {}
        self._next_id: int = 1
        self._store_path: Path = store_path or Path(
            os.getenv("KL1_OUTBOUND_STORE", str(_default_store_path()))
        )
        self._load()

    def _load(self) -> None:
        if not self._store_path.exists():
            return
        try:
            raw = json.loads(self._store_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return
            for obj in raw:
                ca = obj.get("created_at")
                if isinstance(ca, str):
                    try:
                        obj["created_at"] = datetime.fromisoformat(ca)
                    except Exception:
                        obj["created_at"] = datetime.utcnow()
                camp = OutboundCampaign(**obj)
                self._items[camp.id] = camp
            if self._items:
                self._next_id = max(self._items.keys()) + 1
        except Exception:
            return

    def _save(self) -> None:
        try:
            payload = []
            for camp in self._items.values():
                d = camp.model_dump()
                if isinstance(d.get("created_at"), datetime):
                    d["created_at"] = d["created_at"].isoformat()
                payload.append(d)
            tmp = self._store_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self._store_path)
        except Exception:
            return

    def list(self, opportunity_id: Optional[int] = None, limit: int = 200) -> List[OutboundCampaign]:
        items = list(self._items.values())
        if opportunity_id is not None:
            items = [c for c in items if c.opportunity_id == opportunity_id]
        items.sort(key=lambda c: c.created_at, reverse=True)
        return items[:limit]

    def get(self, campaign_id: int) -> Optional[OutboundCampaign]:
        return self._items.get(campaign_id)

    def create(self, campaign: OutboundCampaign) -> OutboundCampaign:
        self._items[campaign.id] = campaign
        self._next_id = max(self._next_id, campaign.id + 1)
        self._save()
        return campaign

    def new_id(self) -> int:
        nid = self._next_id
        self._next_id += 1
        return nid

    def update(self, campaign_id: int, campaign: OutboundCampaign) -> OutboundCampaign:
        self._items[campaign_id] = campaign
        self._save()
        return campaign

    def delete(self, campaign_id: int) -> bool:
        ok = self._items.pop(campaign_id, None) is not None
        if ok:
            self._save()
        return ok


outbound_registry = OutboundRegistry()
