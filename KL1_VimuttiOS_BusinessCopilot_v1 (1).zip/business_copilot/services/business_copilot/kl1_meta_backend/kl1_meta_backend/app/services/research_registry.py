from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..models.research_item import ResearchItem
from ..schemas.research_item import ResearchItemCreate, ResearchItemUpdate

def _fingerprint(source: str, title: str, url: Optional[str], summary: Optional[str], payload: Optional[dict]) -> str:
    """Create a stable fingerprint for de-duplication.

    We prefer URL when present; otherwise we hash normalized title+summary+payload hints.
    """
    parts: List[str] = [source.strip().lower(), (url or "").strip().lower(), title.strip().lower()]
    if summary:
        parts.append(summary.strip().lower()[:400])
    if payload:
        # include a tiny hint so different payload types don't collide
        meta = payload.get("_meta") if isinstance(payload, dict) else None
        ptype = None
        if isinstance(meta, dict):
            ptype = meta.get("type")
        parts.append(str(ptype or ""))
    raw = "|".join(parts)
    return __import__("hashlib").sha256(raw.encode("utf-8")).hexdigest()




def _default_store_path() -> Path:
    # Default: <package>/data/research_items.json
    app_dir = Path(__file__).resolve().parents[1]
    data_dir = app_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "research_items.json"


class ResearchRegistry:
    """
    In-memory registry with light JSON persistence.

    Why: A business pilot that forgets everything after restart is… spiritually interesting,
    but economically tragic.
    """

    def __init__(self, store_path: Optional[Path] = None) -> None:
        self._items: Dict[int, ResearchItem] = {}
        self._next_id: int = 1
        self._store_path: Path = store_path or Path(os.getenv("KL1_RESEARCH_STORE", str(_default_store_path())))
        self._load()

    def _load(self) -> None:
        if not self._store_path.exists():
            return
        try:
            raw = json.loads(self._store_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return
            for obj in raw:
                # created_at may be missing in older dumps
                ca = obj.get("created_at")
                if isinstance(ca, str):
                    try:
                        obj["created_at"] = datetime.fromisoformat(ca)
                    except Exception:
                        obj["created_at"] = datetime.utcnow()
                item = ResearchItem(**obj)
                self._items[item.id] = item
            if self._items:
                self._next_id = max(self._items.keys()) + 1
        except Exception:
            # Fail-open: keep in-memory registry usable even if the JSON is corrupted.
            return

    def _save(self) -> None:
        try:
            payload = []
            for item in self._items.values():
                d = item.model_dump()
                # datetime -> iso
                if isinstance(d.get("created_at"), datetime):
                    d["created_at"] = d["created_at"].isoformat()
                payload.append(d)
            tmp = self._store_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self._store_path)
        except Exception:
            # Fail-open: never crash API writes due to storage issues.
            return

    def list(self, tag: Optional[str] = None, limit: int = 100) -> List[ResearchItem]:
        items = list(self._items.values())
        if tag:
            items = [i for i in items if tag in i.tags]
        return items[:limit]

    def get(self, item_id: int) -> Optional[ResearchItem]:
        return self._items.get(item_id)

    def create(self, data: ResearchItemCreate) -> ResearchItem:
        item = ResearchItem(id=self._next_id, **data.model_dump())
        self._items[self._next_id] = item
        self._next_id += 1
        self._save()
        return item

    def update(self, item_id: int, data: ResearchItemUpdate) -> Optional[ResearchItem]:
        existing = self._items.get(item_id)
        if not existing:
            return None
        update_data = data.model_dump(exclude_unset=True)
        updated = existing.model_copy(update=update_data)
        self._items[item_id] = updated
        self._save()
        return updated

    def delete(self, item_id: int) -> bool:
        ok = self._items.pop(item_id, None) is not None
        if ok:
            self._save()
        return ok




    def find_by_fingerprint(self, fp: str) -> Optional[ResearchItem]:
        for it in self._items.values():
            payload = it.payload or {}
            meta = payload.get("_meta") if isinstance(payload, dict) else None
            if isinstance(meta, dict) and meta.get("fingerprint") == fp:
                return it
        return None

    def upsert_by_fingerprint(self, data: ResearchItemCreate) -> tuple[ResearchItem, str]:
        """Create or update an item based on fingerprint.

        Returns: (item, action) where action is 'created'|'updated'|'skipped'
        """
        fp = _fingerprint(data.source, data.title, data.url, data.summary, data.payload)
        existing = self.find_by_fingerprint(fp)
        # ensure meta exists
        payload = data.payload or {}
        if not isinstance(payload, dict):
            payload = {"value": payload}
        meta = payload.get("_meta")
        if not isinstance(meta, dict):
            meta = {}
        meta.setdefault("fingerprint", fp)
        payload["_meta"] = meta
        data = data.model_copy(update={"payload": payload})

        if existing is None:
            created = self.create(data)
            return created, "created"

        # Merge conservatively: union tags, fill missing summary/url.
        merged_tags = sorted(set((existing.tags or []) + (data.tags or [])))
        update_fields = {
            "tags": merged_tags,
        }
        if (not existing.url) and data.url:
            update_fields["url"] = data.url
        if (not existing.summary) and data.summary:
            update_fields["summary"] = data.summary

        # merge payload (shallow)
        existing_payload = existing.payload or {}
        if not isinstance(existing_payload, dict):
            existing_payload = {"value": existing_payload}
        merged_payload = {**existing_payload, **payload}
        # keep meta fingerprint
        mmeta = merged_payload.get("_meta")
        if not isinstance(mmeta, dict):
            mmeta = {}
        mmeta["fingerprint"] = fp
        merged_payload["_meta"] = mmeta
        update_fields["payload"] = merged_payload

        updated = self.update(existing.id, ResearchItemUpdate(**update_fields))
        return updated, "updated"


research_registry = ResearchRegistry()