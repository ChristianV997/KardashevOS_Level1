from __future__ import annotations

import csv
import io
from typing import List, Tuple, Dict, Any, Optional

from ..schemas.research_item import ResearchItemCreate
from ..schemas.market_scout import CsvIngestOptions, IngestResult
from ..services.research_registry import research_registry


COMMON_COLS = {
    "title": ["title", "headline", "name"],
    "url": ["url", "link", "href", "source_url"],
    "summary": ["summary", "description", "snippet", "text"],
    "tags": ["tags", "labels"],
    "company": ["company", "business", "org", "organization"],
    "email": ["email", "e-mail"],
    "phone": ["phone", "tel", "telephone"],
    "website": ["website", "site", "domain"],
    "niche": ["niche", "industry", "category"],
    "notes": ["notes", "note", "comments", "comment"],
    "name": ["contact", "person", "full_name", "name"],
}


def _pick_col(field: str, header: List[str], preferred: Optional[str]) -> Optional[str]:
    if preferred and preferred in header:
        return preferred
    lower = {h.lower(): h for h in header}
    for cand in COMMON_COLS.get(field, []):
        if cand in lower:
            return lower[cand]
    return None


def ingest_csv_bytes(content: bytes, opts: CsvIngestOptions) -> IngestResult:
    created = updated = skipped = 0
    created_ids: List[int] = []
    updated_ids: List[int] = []
    warnings: List[str] = []

    decoded = content.decode("utf-8", errors="replace")
    buf = io.StringIO(decoded)
    reader = csv.DictReader(buf)
    if not reader.fieldnames:
        return IngestResult(created=0, updated=0, skipped=0, total_rows=0, warnings=["CSV has no header row."])

    header = list(reader.fieldnames)

    title_col = _pick_col("title", header, opts.title_col)
    url_col = _pick_col("url", header, opts.url_col)
    summary_col = _pick_col("summary", header, opts.summary_col)
    tags_col = _pick_col("tags", header, opts.tags_col)

    company_col = _pick_col("company", header, opts.company_col)
    name_col = _pick_col("name", header, opts.name_col)
    email_col = _pick_col("email", header, opts.email_col)
    phone_col = _pick_col("phone", header, opts.phone_col)
    website_col = _pick_col("website", header, opts.website_col)
    niche_col = _pick_col("niche", header, opts.niche_col)
    notes_col = _pick_col("notes", header, opts.notes_col)

    total = 0
    for row in reader:
        total += 1
        row_tags: List[str] = []
        if tags_col and row.get(tags_col):
            row_tags.extend([t.strip() for t in str(row.get(tags_col, "")).split(",") if t.strip()])
        all_tags = sorted(set((opts.tags or []) + row_tags + ["market_scout", opts.item_type]))

        # Title fallback strategy
        title = None
        if title_col and row.get(title_col):
            title = str(row.get(title_col)).strip()
        elif company_col and row.get(company_col):
            title = f"{opts.item_type.title()}: {str(row.get(company_col)).strip()}"
        elif email_col and row.get(email_col):
            title = f"{opts.item_type.title()}: {str(row.get(email_col)).strip()}"
        else:
            title = f"{opts.item_type.title()} row {total}"

        url = str(row.get(url_col)).strip() if url_col and row.get(url_col) else None
        summary = str(row.get(summary_col)).strip() if summary_col and row.get(summary_col) else None

        payload: Dict[str, Any] = {
            "_meta": {"type": opts.item_type, "ingest": "csv"},
            "row": row,
        }

        # Normalize lead fields into payload.lead (if present)
        lead: Dict[str, Any] = {}
        for key, col in [
            ("company", company_col),
            ("name", name_col),
            ("email", email_col),
            ("phone", phone_col),
            ("website", website_col),
            ("niche", niche_col),
            ("notes", notes_col),
        ]:
            if col and row.get(col):
                lead[key] = str(row.get(col)).strip()
        if lead:
            payload["lead"] = lead

        item = ResearchItemCreate(
            title=title,
            source=opts.source,
            url=url,
            summary=summary,
            tags=all_tags,
            payload=payload,
        )

        saved, action = research_registry.upsert_by_fingerprint(item)
        if action == "created":
            created += 1
            created_ids.append(saved.id)
        elif action == "updated":
            updated += 1
            updated_ids.append(saved.id)
        else:
            skipped += 1

    # warn if no meaningful columns detected
    if title_col is None and company_col is None and email_col is None:
        warnings.append("No obvious title/company/email column found; titles were auto-generated.")

    return IngestResult(
        created=created,
        updated=updated,
        skipped=skipped,
        total_rows=total,
        created_ids=created_ids,
        updated_ids=updated_ids,
        warnings=warnings,
    )
