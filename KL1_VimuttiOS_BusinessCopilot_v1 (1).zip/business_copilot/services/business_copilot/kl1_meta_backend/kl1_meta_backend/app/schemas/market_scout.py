from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class CsvIngestOptions(BaseModel):
    source: str = Field(default="csv_upload", description="Label for the source of this ingest.")
    tags: List[str] = Field(default_factory=list, description="Tags applied to all created items.")
    # Column hints (optional). If omitted, auto-detection will try common names.
    title_col: Optional[str] = None
    url_col: Optional[str] = None
    summary_col: Optional[str] = None
    tags_col: Optional[str] = None

    # If this CSV is a lead list, map these columns (optional)
    company_col: Optional[str] = None
    name_col: Optional[str] = None
    email_col: Optional[str] = None
    phone_col: Optional[str] = None
    website_col: Optional[str] = None
    niche_col: Optional[str] = None
    notes_col: Optional[str] = None

    item_type: str = Field(default="signal", description="signal | lead | note")


class TextIngestRequest(BaseModel):
    source: str = "manual_text"
    title: str
    text: str
    url: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    item_type: str = "signal"
    extra: Dict[str, Any] = Field(default_factory=dict)


class IngestResult(BaseModel):
    created: int
    updated: int
    skipped: int
    total_rows: int
    created_ids: List[int] = Field(default_factory=list)
    updated_ids: List[int] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
