from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field


class EquationBase(BaseModel):
    name: str
    latex: str
    domain: str = "unknown"
    status: str = "candidate"
    gps_score: Optional[float] = None
    notes: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None


class EquationCreate(EquationBase):
    pass


class EquationUpdate(BaseModel):
    name: Optional[str] = None
    latex: Optional[str] = None
    domain: Optional[str] = None
    status: Optional[str] = None
    gps_score: Optional[float] = None
    notes: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None


class EquationRead(EquationBase):
    id: int
    created_at: datetime
