from typing import List, Optional
from fastapi import APIRouter, HTTPException
from ....schemas.research_item import (
    ResearchItemCreate,
    ResearchItemRead,
    ResearchItemUpdate,
)
from ....services.research_registry import research_registry

router = APIRouter()


@router.get("/", response_model=List[ResearchItemRead])
def list_research_items(tag: Optional[str] = None, limit: int = 100):
    return research_registry.list(tag=tag, limit=limit)


@router.post("/", response_model=ResearchItemRead, status_code=201)
def create_research_item(data: ResearchItemCreate):
    return research_registry.create(data)


@router.get("/{item_id}", response_model=ResearchItemRead)
def get_research_item(item_id: int):
    item = research_registry.get(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="ResearchItem not found")
    return item


@router.patch("/{item_id}", response_model=ResearchItemRead)
def update_research_item(item_id: int, data: ResearchItemUpdate):
    updated = research_registry.update(item_id, data)
    if not updated:
        raise HTTPException(status_code=404, detail="ResearchItem not found")
    return updated


@router.delete("/{item_id}", status_code=204)
def delete_research_item(item_id: int):
    ok = research_registry.delete(item_id)
    if not ok:
        raise HTTPException(status_code=404, detail="ResearchItem not found")
    return
