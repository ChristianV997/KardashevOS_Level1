from __future__ import annotations

from fastapi import APIRouter, File, UploadFile, Query, HTTPException
from typing import Optional, List

from ....schemas.market_scout import CsvIngestOptions, TextIngestRequest, IngestResult
from ....schemas.research_item import ResearchItemCreate, ResearchItemRead
from ....services.market_scout import ingest_csv_bytes
from ....services.research_registry import research_registry


router = APIRouter()


@router.post("/ingest/csv", response_model=IngestResult)
async def ingest_csv(
    file: UploadFile = File(...),
    source: str = Query("csv_upload"),
    item_type: str = Query("signal", description="signal | lead | note"),
    tags: Optional[str] = Query(None, description="Comma-separated tags to apply to all rows."),
) -> IngestResult:
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are supported in this endpoint.")
    content = await file.read()
    base_tags: List[str] = []
    if tags:
        base_tags = [t.strip() for t in tags.split(",") if t.strip()]
    opts = CsvIngestOptions(source=source, tags=base_tags, item_type=item_type)
    return ingest_csv_bytes(content, opts)


@router.post("/ingest/text", response_model=ResearchItemRead)
def ingest_text(req: TextIngestRequest) -> ResearchItemRead:
    payload = {"_meta": {"type": req.item_type, "ingest": "text"}, "text": req.text, **(req.extra or {})}
    item = ResearchItemCreate(
        title=req.title,
        source=req.source,
        url=req.url,
        tags=sorted(set(req.tags + ["market_scout", req.item_type])),
        summary=(req.text or "")[:400] if req.text else None,
        payload=payload,
    )
    saved, _ = research_registry.upsert_by_fingerprint(item)
    return saved


@router.get("/recent", response_model=list[ResearchItemRead])
def recent(limit: int = 50) -> list[ResearchItemRead]:
    items = sorted(research_registry.list(limit=10000), key=lambda x: x.created_at, reverse=True)
    return items[: max(1, min(limit, 200))]
