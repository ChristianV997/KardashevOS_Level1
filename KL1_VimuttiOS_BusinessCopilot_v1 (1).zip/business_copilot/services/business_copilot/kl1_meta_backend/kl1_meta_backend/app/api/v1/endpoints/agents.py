from typing import List
from fastapi import APIRouter, HTTPException
from ....schemas.agent_state import (
    AgentStateCreate,
    AgentStateRead,
    AgentStateUpdate,
)
from ....services.agent_orchestrator import agent_orchestrator

router = APIRouter()


@router.get("/", response_model=List[AgentStateRead])
def list_agents():
    return agent_orchestrator.list()


@router.post("/", response_model=AgentStateRead, status_code=201)
def create_agent_state(data: AgentStateCreate):
    return agent_orchestrator.create(data)


@router.get("/{name}", response_model=AgentStateRead)
def get_agent_state(name: str):
    state = agent_orchestrator.get(name)
    if not state:
        raise HTTPException(status_code=404, detail="Agent not found")
    return state


@router.patch("/{name}", response_model=AgentStateRead)
def update_agent_state(name: str, data: AgentStateUpdate):
    state = agent_orchestrator.update(name, data)
    if not state:
        raise HTTPException(status_code=404, detail="Agent not found")
    return state


@router.delete("/{name}", status_code=204)
def delete_agent_state(name: str):
    ok = agent_orchestrator.delete(name)
    if not ok:
        raise HTTPException(status_code=404, detail="Agent not found")
    return
