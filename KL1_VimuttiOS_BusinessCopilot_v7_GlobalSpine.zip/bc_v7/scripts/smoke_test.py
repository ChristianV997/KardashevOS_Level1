"""Minimal smoke test for Business Copilot API.

Run:
  python scripts/smoke_test.py
"""

import sys
import types
from pathlib import Path

from fastapi.testclient import TestClient

# Ensure backend package is importable when running from repo root
ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "services" / "business_copilot" / "kl1_meta_backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

# ---------------------------------------------------------------------------
# NOTE: FastAPI requires the ``python_multipart`` package when using UploadFile
# or File parameters. This runtime may not have the dependency installed. To
# avoid import errors during application startup we provide a simple stub
# module before importing the FastAPI app. If the real package is present
# this has no effect; otherwise the stub satisfies ``import python_multipart``.
if 'python_multipart' not in sys.modules:
    sys.modules['python_multipart'] = types.ModuleType('python_multipart')

from kl1_meta_backend.app.main import app


def main() -> None:
    c = TestClient(app)
    assert c.get("/health").status_code == 200

    # Create opportunity
    opp_payload = {
        "title": "Dental: missed-call recovery",
        "summary": "Automate missed call follow-up to recover leads.",
        "tags": ["revops"],
        "opportunity": {
            "niche": "dental",
            "offer_tier": "A",
            "name": "Missed-call Recovery",
            "problem": "Leads vanish when phones aren't answered.",
            "proposed_offer": "Install missed-call SMS + intake + booking automation in 7 days.",
            "features": {
                "pain": 0.9,
                "budget": 0.8,
                "reachability": 0.7,
                "speed": 0.9,
                "fulfillment_fit": 0.8,
                "moat": 0.6,
                "risk": 0.1,
                "load": 0.3,
            },
        },
    }
    r = c.post("/api/v1/opportunities/", json=opp_payload)
    assert r.status_code in (200, 201), r.text
    opp_id = r.json()["id"]

    # Ingest a small lead batch (so LeadSieve can auto-generate opportunities)
    for i in range(5):
        lead_text = {
            "source": "manual",
            "title": f"Lead: Dental Clinic {i+1}",
            "text": "",
            "tags": ["LEADS_DENTAL_SAMPLE"],
            "item_type": "lead",
            "extra": {
                "row": {
                    "company": f"Dental Clinic {i+1}",
                    "email": f"owner{i+1}@clinic.example",
                    "industry": "dental",
                    "phone": "+15555550000",
                }
            },
        }
        r = c.post("/api/v1/market_scout/ingest/text", json=lead_text)
        assert r.status_code == 200, r.text

    # Ingest a couple of similar signals for sieve clustering
    s1 = {
        "source": "manual",
        "title": "Signal: dental missed calls",
        "text": "Dentist offices keep missing calls; front desk overloaded; leads vanish.",
        "tags": ["SIG_DENTAL_SAMPLE"],
        "item_type": "signal",
    }
    s2 = {
        "source": "manual",
        "title": "Signal: missed-call follow-up",
        "text": "Missed calls in dental clinics are common; follow-up automation could recover bookings.",
        "tags": ["SIG_DENTAL_SAMPLE"],
        "item_type": "signal",
    }
    r = c.post("/api/v1/market_scout/ingest/text", json=s1)
    assert r.status_code == 200, r.text
    r = c.post("/api/v1/market_scout/ingest/text", json=s2)
    assert r.status_code == 200, r.text

    # Cluster signals
    r = c.post("/api/v1/sieve/cluster", json={"item_type": "signal", "tags_any": ["SIG_DENTAL_SAMPLE"], "limit": 100, "similarity_threshold": 0.2, "min_cluster_size": 2})
    assert r.status_code == 200, r.text
    assert len(r.json().get("clusters", [])) >= 1

    # Generate opportunities from clusters
    r = c.post("/api/v1/sieve/generate_opportunities", json={"item_type": "signal", "tags_any": ["SIG_DENTAL_SAMPLE"], "limit": 100, "similarity_threshold": 0.2, "min_cluster_size": 2})
    assert r.status_code == 200, r.text
    assert r.json().get("created", 0) >= 1

    # Generate opportunities from leads (LeadSieve)
    r = c.post(
        "/api/v1/sieve/generate_from_leads",
        json={"lead_tag": "LEADS_DENTAL_SAMPLE", "group_field": "industry", "min_group_size": 2},
    )
    assert r.status_code == 200, r.text
    assert r.json().get("created", 0) >= 1

    # Generate outbound A/B campaigns (creates two experiments)
    gen_ab = {
        "opportunity_id": opp_id,
        "lead_tag": "LEADS_DENTAL_SAMPLE",
        "channel": "email",
        "language": "en",
        "sequence_steps": 3,
        "variant_a": "A",
        "variant_b": "B",
        "sender_name": "Christian",
        "agency_name": "KL1 Growth Ops",
        "calendar_link": "https://calendly.com/your-link",
        "auto_create_experiment": True,
    }
    r = c.post("/api/v1/outbound/generate_ab", json=gen_ab)
    assert r.status_code == 200, r.text
    camp_id = r.json()["campaign_id_a"]
    exp_id = r.json().get("experiment_id_a")
    assert exp_id is not None

    # Approve and export (approval gate should work)
    r = c.post(f"/api/v1/outbound/campaigns/{camp_id}/approve")
    assert r.status_code == 200, r.text
    r = c.get(f"/api/v1/outbound/campaigns/{camp_id}/export/csv")
    assert r.status_code == 200, r.text

    # Log some results
    r = c.post(f"/api/v1/outbound/campaigns/{camp_id}/log", json={"outreaches": 100, "replies": 6, "booked_calls": 2})
    assert r.status_code == 200, r.text

    # Complete experiment (triggers adaptation)
    r = c.post(f"/api/v1/experiments/{exp_id}/complete")
    assert r.status_code == 200, r.text

    # Run evals
    r = c.get("/api/v1/evals/run")
    assert r.status_code == 200, r.text
    assert r.json().get("passed") is True

    # Global spine: dry run ingestion
    # Use query parameters to avoid body parsing in the FastAPI router
    r = c.post("/api/v1/global/run?dry_run=true")
    assert r.status_code == 200, r.text

    # Ensure waves endpoint returns at least one entry
    r = c.get("/api/v1/global/waves")
    assert r.status_code == 200, r.text
    waves = r.json().get("waves", [])
    assert isinstance(waves, list) and len(waves) >= 1

    # Draft opportunities from top macro waves
    r = c.post("/api/v1/global/opportunities?top_n=3")
    assert r.status_code == 200, r.text
    created = r.json().get("created", [])
    assert isinstance(created, list) and len(created) >= 1

    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
