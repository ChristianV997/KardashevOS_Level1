from typing import Dict, List, Optional
from ..models.equation import Equation
from ..schemas.equation import EquationCreate, EquationUpdate


class EquationRegistry:
    def __init__(self) -> None:
        self._items: Dict[int, Equation] = {}
        self._next_id: int = 1

    def list(self, domain: Optional[str] = None, limit: int = 100) -> List[Equation]:
        items = list(self._items.values())
        if domain:
            items = [e for e in items if e.domain == domain]
        return items[:limit]

    def get(self, eq_id: int) -> Optional[Equation]:
        return self._items.get(eq_id)

    def create(self, data: EquationCreate) -> Equation:
        eq = Equation(id=self._next_id, **data.model_dump())
        self._items[self._next_id] = eq
        self._next_id += 1
        return eq

    def update(self, eq_id: int, data: EquationUpdate) -> Optional[Equation]:
        existing = self._items.get(eq_id)
        if not existing:
            return None
        update_data = data.model_dump(exclude_unset=True)
        updated = existing.model_copy(update=update_data)
        self._items[eq_id] = updated
        return updated

    def delete(self, eq_id: int) -> bool:
        return self._items.pop(eq_id, None) is not None


equation_registry = EquationRegistry()
