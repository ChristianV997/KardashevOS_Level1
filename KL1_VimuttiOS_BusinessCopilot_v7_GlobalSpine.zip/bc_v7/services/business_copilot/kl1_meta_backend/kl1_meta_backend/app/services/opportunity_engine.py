from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from ..schemas.opportunity import OpportunityPayload, OpportunityFeatures
from ..schemas.research_item import ResearchItemCreate, ResearchItemUpdate
from ..models.research_item import ResearchItem
from .research_registry import research_registry


DEFAULT_WEIGHTS: Dict[str, float] = {
    "pain": 0.20,
    "budget": 0.15,
    "reachability": 0.10,
    "speed": 0.15,
    "fulfillment_fit": 0.15,
    "moat": 0.15,
    "risk": 0.05,
    "load": 0.05,
}


def clamp01(x: float) -> float:
    if x < 0:
        return 0.0
    if x > 1:
        return 1.0
    return float(x)


def compute_gps(features: OpportunityFeatures, weights: Optional[Dict[str, float]] = None) -> float:
    w = dict(DEFAULT_WEIGHTS)
    if weights:
        for k, v in weights.items():
            if k in w:
                w[k] = float(v)

    # Positive drivers
    pos = (
        w["pain"] * features.pain
        + w["budget"] * features.budget
        + w["reachability"] * features.reachability
        + w["speed"] * features.speed
        + w["fulfillment_fit"] * features.fulfillment_fit
        + w["moat"] * features.moat
    )
    # Negative drivers
    neg = (w["risk"] * features.risk) + (w["load"] * features.load)

    # Simple clamp (keeps it interpretable)
    return clamp01(pos - neg)


def ensure_opportunity_tags(tags: List[str], niche: str, offer_tier: str) -> List[str]:
    t = list(dict.fromkeys(tags))  # stable unique
    for tag in ["opportunity", f"niche:{niche}", f"tier:{offer_tier}"]:
        if tag not in t:
            t.append(tag)
    return t


def create_opportunity_item(
    title: str,
    source: str,
    url: Optional[str],
    tags: List[str],
    summary: Optional[str],
    opportunity: OpportunityPayload,
) -> ResearchItem:
    gps = compute_gps(opportunity.features, opportunity.weights)
    opportunity.gps_score = gps
    tags2 = ensure_opportunity_tags(tags, opportunity.niche, opportunity.offer_tier)

    item = research_registry.create(
        ResearchItemCreate(
            title=title,
            source=source,
            url=url,
            tags=tags2,
            gps_score=gps,
            summary=summary,
            payload={"type": "opportunity", "opportunity": opportunity.model_dump()},
        )
    )
    return item


def list_opportunities(niche: Optional[str] = None, limit: int = 100) -> List[ResearchItem]:
    items = research_registry.list(tag="opportunity", limit=limit)
    if niche:
        items = [i for i in items if f"niche:{niche}" in i.tags]
    # Sort by gps_score desc (None last)
    items.sort(key=lambda x: (x.gps_score is not None, x.gps_score or 0.0), reverse=True)
    return items[:limit]


def update_opportunity_item(item_id: int, updated_payload: OpportunityPayload, recompute: bool = True) -> Optional[ResearchItem]:
    existing = research_registry.get(item_id)
    if not existing:
        return None
    gps = existing.gps_score
    if recompute:
        gps = compute_gps(updated_payload.features, updated_payload.weights)
        updated_payload.gps_score = gps

    tags = existing.tags or []
    tags2 = ensure_opportunity_tags(tags, updated_payload.niche, updated_payload.offer_tier)

    return research_registry.update(
        item_id,
        ResearchItemUpdate(
            tags=tags2,
            gps_score=gps,
            payload={"type": "opportunity", "opportunity": updated_payload.model_dump()},
        ),
    )


def validate_opportunity_item(item: ResearchItem) -> Tuple[bool, str]:
    try:
        p = (item.payload or {}).get("opportunity")
        if not p:
            return False, "Missing payload.opportunity"
        OpportunityPayload(**p)  # schema validation
        return True, "ok"
    except Exception as e:
        return False, str(e)
