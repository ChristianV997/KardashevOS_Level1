from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

from ..models.research_item import ResearchItem
from ..schemas.opportunity import OpportunityPayload, OpportunityFeatures
from ..schemas.research_item import ResearchItemUpdate
from ..services.opportunity_engine import create_opportunity_item
from ..services.research_registry import research_registry


STOPWORDS = {
    # tiny, dependency-free list; keep it short so we don't remove meaningful niche tokens
    "the", "a", "an", "and", "or", "to", "of", "for", "in", "on", "with", "from", "at", "by",
    "is", "are", "be", "this", "that", "it", "as", "we", "you", "your", "our", "they", "their",
    "can", "will", "not", "no", "yes", "do", "does", "did", "done", "into", "over", "under",
    "than", "then", "more", "most", "less", "least", "very", "just", "also", "only", "about",
}


def _normalize_text(item: ResearchItem) -> str:
    parts: List[str] = []
    if item.title:
        parts.append(item.title)
    if item.summary:
        parts.append(item.summary)
    p = item.payload or {}
    if isinstance(p, dict):
        # include common MarketScout payload fields
        row = p.get("row")
        if isinstance(row, dict):
            parts.append(" ".join([str(v) for v in row.values() if v]))
        lead = p.get("lead")
        if isinstance(lead, dict):
            parts.append(" ".join([str(v) for v in lead.values() if v]))
        txt = p.get("text")
        if isinstance(txt, str):
            parts.append(txt)
    return "\n".join(parts)


TOKEN_RE = re.compile(r"[a-zA-Z0-9]{2,}")


def _tokens(text: str) -> List[str]:
    toks = [t.lower() for t in TOKEN_RE.findall(text or "")]
    return [t for t in toks if t not in STOPWORDS]


def _vector(tokens: List[str]) -> Counter:
    return Counter(tokens)


def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    dot = 0
    for k, v in a.items():
        dot += v * b.get(k, 0)
    if dot == 0:
        return 0.0
    na = sum(v*v for v in a.values()) ** 0.5
    nb = sum(v*v for v in b.values()) ** 0.5
    if na == 0 or nb == 0:
        return 0.0
    return float(dot) / float(na*nb)


@dataclass
class _Cluster:
    id: str
    centroid: Counter
    item_ids: List[int]
    keywords: List[str]


def _cluster_id(n: int) -> str:
    return f"c{n:04d}"


def cluster_items(items: List[ResearchItem], threshold: float, min_size: int) -> List[_Cluster]:
    """Greedy clustering on token-count cosine similarity.

    This is intentionally dependency-free (no sklearn) and works well enough for pilot-scale volumes.
    """
    # Precompute vectors
    vecs: Dict[int, Counter] = {}
    for it in items:
        vecs[it.id] = _vector(_tokens(_normalize_text(it)))

    clusters: List[_Cluster] = []
    next_idx = 1

    for it in items:
        v = vecs.get(it.id) or Counter()
        best_i = -1
        best_sim = 0.0
        for i, c in enumerate(clusters):
            sim = _cosine(v, c.centroid)
            if sim > best_sim:
                best_sim = sim
                best_i = i
        if best_i >= 0 and best_sim >= threshold:
            c = clusters[best_i]
            c.item_ids.append(it.id)
            # Update centroid (running sum)
            c.centroid = c.centroid + v
        else:
            clusters.append(_Cluster(id=_cluster_id(next_idx), centroid=v, item_ids=[it.id], keywords=[]))
            next_idx += 1

    # Compute keywords & filter small clusters
    out: List[_Cluster] = []
    for c in clusters:
        if len(c.item_ids) < min_size:
            continue
        # top keywords from centroid
        kws = [k for k, _ in c.centroid.most_common(12) if k not in STOPWORDS]
        c.keywords = kws[:8]
        out.append(c)
    # sort by size desc
    out.sort(key=lambda x: len(x.item_ids), reverse=True)
    return out


_NICHE_RULES: List[Tuple[str, str]] = [
    ("dental", "dental"),
    ("dentist", "dental"),
    ("medspa", "medspa"),
    ("spa", "medspa"),
    ("law", "legal"),
    ("attorney", "legal"),
    ("realtor", "real_estate"),
    ("real", "real_estate"),
    ("clinic", "clinic"),
    ("painting", "home_services"),
    ("cleaning", "home_services"),
    ("landscaping", "home_services"),
]


def infer_niche(tags: List[str], keywords: List[str]) -> str:
    for t in tags or []:
        if isinstance(t, str) and t.startswith("niche:"):
            return t.split(":", 1)[1].strip() or "general"
    joined = " ".join(keywords).lower()
    for needle, niche in _NICHE_RULES:
        if needle in joined:
            return niche
    return "general"


def default_features_for_cluster(keywords: List[str]) -> OpportunityFeatures:
    # Conservative defaults
    pain = 0.6
    budget = 0.55
    reachability = 0.55
    speed = 0.7
    fulfillment_fit = 0.65
    moat = 0.4
    risk = 0.15
    load = 0.35

    k = " ".join(keywords).lower()
    if "compliance" in k or "regulation" in k or "law" in k:
        budget += 0.15
        pain += 0.1
        speed -= 0.1
        moat += 0.15
        risk += 0.1
    if "missed" in k and "call" in k:
        pain += 0.15
        speed += 0.1
        fulfillment_fit += 0.1
    if "outreach" in k or "lead" in k:
        reachability += 0.1
        speed += 0.05
    return OpportunityFeatures(
        pain=min(1.0, pain),
        budget=min(1.0, budget),
        reachability=min(1.0, reachability),
        speed=min(1.0, speed),
        fulfillment_fit=min(1.0, fulfillment_fit),
        moat=min(1.0, moat),
        risk=min(1.0, risk),
        load=min(1.0, load),
    )


def summarize_cluster(items: List[ResearchItem], keywords: List[str]) -> str:
    titles = [it.title for it in items if it.title]
    sample = "; ".join(titles[:3])
    kw = ", ".join(keywords[:6])
    return f"Auto-clustered from {len(items)} signals. Keywords: {kw}. Samples: {sample}".strip()


def run_sieve(
    *,
    item_type: str,
    tags_any: Optional[List[str]],
    limit: int,
    similarity_threshold: float,
    min_cluster_size: int,
) -> Tuple[List[_Cluster], List[ResearchItem]]:
    items = research_registry.list_by_type(item_type, tags_any=tags_any, limit=limit)
    clusters = cluster_items(items, threshold=similarity_threshold, min_size=min_cluster_size)
    return clusters, items


def generate_opportunities_from_clusters(
    clusters: List[_Cluster],
    items_by_id: Dict[int, ResearchItem],
    *,
    source: str,
    base_tags: List[str],
    default_offer_tier: str,
) -> List[ResearchItem]:
    created: List[ResearchItem] = []
    for c in clusters:
        cluster_items_list = [items_by_id[i] for i in c.item_ids if i in items_by_id]
        if not cluster_items_list:
            continue
        # aggregate tags
        agg_tags: List[str] = []
        for it in cluster_items_list:
            agg_tags.extend(it.tags or [])
        agg_tags = sorted(set(agg_tags + base_tags + ["auto_opportunity"]))

        niche = infer_niche(agg_tags, c.keywords)
        features = default_features_for_cluster(c.keywords)

        # Simple offer name + problem statement
        name = " / ".join(c.keywords[:3]) or "Cluster Opportunity"
        problem = "Repeated signals indicate a consistent buyer pain." 
        proposed_offer = "Ship a fast MVP test (landing + outreach + follow-up) and iterate weekly." 

        opp = OpportunityPayload(
            niche=niche,
            offer_tier=default_offer_tier,
            name=name,
            problem=problem,
            proposed_offer=proposed_offer,
            features=features,
            weights=None,
            experiments=[],
            gps_score=None,
        )

        title = f"Auto Opportunity ({niche}): {name}".strip()
        summary = summarize_cluster(cluster_items_list, c.keywords)

        item = create_opportunity_item(
            title=title,
            source=source,
            url=None,
            tags=agg_tags + [f"cluster:{c.id}"],
            summary=summary,
            opportunity=opp,
        )
        # add trace to payload
        payload = item.payload or {}
        if isinstance(payload, dict):
            payload.setdefault("sieve", {})
            payload["sieve"] = {
                "cluster_id": c.id,
                "keywords": c.keywords,
                "source_item_ids": c.item_ids,
            }
        # update with enriched payload
        updated = research_registry.update(item.id, ResearchItemUpdate(payload=payload))
        created.append(updated or item)
    return created
