from __future__ import annotations

import math
from typing import Any, Dict, Optional, Tuple

from ..schemas.opportunity import OpportunityPayload, OpportunityFeatures
from ..models.research_item import ResearchItem
from ..schemas.research_item import ResearchItemUpdate
from .opportunity_engine import compute_gps, clamp01
from .research_registry import research_registry


def _get_num(metrics: Dict[str, Any], key: str) -> Optional[float]:
    v = metrics.get(key)
    if v is None:
        return None
    try:
        return float(v)
    except Exception:
        return None


def _saturating_score(x: float, good: float, great: float) -> float:
    """Map x to 0..1 with a simple saturation curve.

    - x <= 0 -> 0
    - x ~= good -> ~0.5
    - x >= great -> ~1
    """
    if x <= 0:
        return 0.0
    if x >= great:
        return 1.0
    # linear between 0 and great, but give a "knee" around good
    return clamp01(x / great)


def compute_outcome_score(metrics: Dict[str, Any]) -> Tuple[float, Dict[str, float]]:
    """Compute a 0..1 outcome score from common experiment metrics.

    Expected keys (optional):
      outreaches, replies, booked_calls, shows, closes, revenue_usd, cost_usd
    """
    outreaches = _get_num(metrics, "outreaches")
    replies = _get_num(metrics, "replies")
    booked = _get_num(metrics, "booked_calls")
    shows = _get_num(metrics, "shows")
    closes = _get_num(metrics, "closes")
    revenue = _get_num(metrics, "revenue_usd")
    cost = _get_num(metrics, "cost_usd")

    # Rates
    reply_rate = (replies / outreaches) if (outreaches and replies is not None) else None
    book_rate = (booked / outreaches) if (outreaches and booked is not None) else None
    show_rate = (shows / booked) if (booked and shows is not None) else None
    close_rate = (closes / shows) if (shows and closes is not None) else (closes / booked) if (booked and closes is not None) else None

    # ROI (fail-open: if revenue missing, treat as 0)
    cost2 = cost if cost is not None else 0.0
    revenue2 = revenue if revenue is not None else 0.0
    denom = max(cost2, 1.0)
    roi = (revenue2 - cost2) / denom

    # Scores with baselines typical for SMB outbound
    s_reply = _saturating_score(reply_rate or 0.0, good=0.05, great=0.20)
    s_book = _saturating_score(book_rate or 0.0, good=0.02, great=0.10)
    s_close = _saturating_score(close_rate or 0.0, good=0.20, great=0.50)
    s_roi = _saturating_score(max(roi, 0.0), good=1.0, great=5.0)

    # Only weight what we actually have
    parts = {
        "reply": s_reply,
        "book": s_book,
        "close": s_close,
        "roi": s_roi,
    }

    weights = {
        "reply": 0.25,
        "book": 0.25,
        "close": 0.25,
        "roi": 0.25,
    }
    # If outreaches is missing, reply/book are not meaningful
    if outreaches is None:
        weights["reply"] = 0.0
        weights["book"] = 0.0
    if close_rate is None:
        weights["close"] = 0.0
    if revenue is None and cost is None:
        weights["roi"] = 0.0

    total_w = sum(w for w in weights.values() if w > 0)
    if total_w <= 0:
        return 0.0, {**parts, "reply_rate": reply_rate or 0.0, "book_rate": book_rate or 0.0, "close_rate": close_rate or 0.0, "roi": roi}

    score = sum(parts[k] * (weights[k] / total_w) for k in parts)
    extras = {
        "reply_rate": reply_rate or 0.0,
        "book_rate": book_rate or 0.0,
        "show_rate": show_rate or 0.0,
        "close_rate": close_rate or 0.0,
        "roi": roi,
    }
    return clamp01(score), {**parts, **extras}


def ema(old: float, new: float, alpha: float = 0.35) -> float:
    return clamp01((1 - alpha) * old + alpha * new)


def _budget_score_from_avg_deal(avg_deal: float) -> float:
    # log scale: $500 -> ~0.3, $5k -> ~0.7, $20k -> ~1
    return clamp01(math.log1p(max(avg_deal, 0.0)) / math.log1p(20000.0))


def adapt_opportunity_from_experiment(opportunity_item: ResearchItem, metrics: Dict[str, Any]) -> Tuple[ResearchItem, Dict[str, Any]]:
    """Update opportunity features + gps_score using experiment outcomes.

    This is intentionally conservative: we *nudge* features rather than overwrite.
    """
    payload = opportunity_item.payload or {}
    opp_raw = payload.get("opportunity")
    if not isinstance(opp_raw, dict):
        return opportunity_item, {"changed": False, "reason": "not_an_opportunity"}

    opp = OpportunityPayload(**opp_raw)
    outcome_score, breakdown = compute_outcome_score(metrics)

    # Map outcomes to feature nudges
    f: OpportunityFeatures = opp.features
    # reachability ~ reply_rate
    reach_n = clamp01(breakdown.get("reply_rate", 0.0) / 0.15)  # 15% replies is "max"
    f.reachability = ema(f.reachability, reach_n)

    # fulfillment_fit ~ book/close performance
    fit_n = clamp01(0.6 * breakdown.get("book", 0.0) + 0.4 * breakdown.get("close", 0.0))
    f.fulfillment_fit = ema(f.fulfillment_fit, fit_n)

    # budget ~ avg deal value (if we have revenue+closes)
    revenue = _get_num(metrics, "revenue_usd")
    closes = _get_num(metrics, "closes")
    if revenue is not None and closes is not None and closes > 0:
        avg_deal = revenue / closes
        f.budget = ema(f.budget, _budget_score_from_avg_deal(avg_deal), alpha=0.25)

    # load ~ effort hours per outcome (if provided)
    effort = _get_num(metrics, "effort_hours")
    booked = _get_num(metrics, "booked_calls")
    if effort is not None and booked is not None and booked > 0:
        hours_per_book = effort / booked
        # lower is better -> invert
        load_n = clamp01(hours_per_book / 5.0)  # 5h/book = heavy
        f.load = ema(f.load, load_n, alpha=0.25)

    # Recompute GPS and blend with outcome score
    gps_model = compute_gps(f, opp.weights)
    gps_blended = clamp01(0.75 * (opportunity_item.gps_score or gps_model) + 0.25 * outcome_score)
    opp.gps_score = gps_blended

    updated = research_registry.update(
        opportunity_item.id,
        ResearchItemUpdate(
            gps_score=gps_blended,
            payload={"type": "opportunity", "opportunity": opp.model_dump()},
        ),
    )
    return updated or opportunity_item, {
        "changed": True,
        "outcome_score": outcome_score,
        "breakdown": breakdown,
        "gps_model": gps_model,
        "gps_blended": gps_blended,
    }
