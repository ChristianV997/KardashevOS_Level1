from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..models.experiment import Experiment
from ..schemas.experiment import ExperimentCreate, ExperimentUpdate


def _default_store_path() -> Path:
    # Default: <package>/data/experiments.json
    app_dir = Path(__file__).resolve().parents[1]
    data_dir = app_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "experiments.json"


class ExperimentRegistry:
    """In-memory experiments with light JSON persistence.

    Experiments are outcome logs (what we tried, what it cost, what happened).
    They drive "agent-output–signaled" adaptation.
    """

    def __init__(self, store_path: Optional[Path] = None) -> None:
        self._items: Dict[int, Experiment] = {}
        self._next_id: int = 1
        self._store_path: Path = store_path or Path(os.getenv("KL1_EXPERIMENTS_STORE", str(_default_store_path())))
        self._load()

    def _load(self) -> None:
        if not self._store_path.exists():
            return
        try:
            raw = json.loads(self._store_path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                return
            for obj in raw:
                for k in ("created_at", "started_at", "ended_at"):
                    v = obj.get(k)
                    if isinstance(v, str):
                        try:
                            obj[k] = datetime.fromisoformat(v)
                        except Exception:
                            obj[k] = None if k != "created_at" else datetime.utcnow()
                exp = Experiment(**obj)
                self._items[exp.id] = exp
            if self._items:
                self._next_id = max(self._items.keys()) + 1
        except Exception:
            return

    def _save(self) -> None:
        try:
            payload = []
            for exp in self._items.values():
                d = exp.model_dump()
                for k in ("created_at", "started_at", "ended_at"):
                    if isinstance(d.get(k), datetime):
                        d[k] = d[k].isoformat()
                payload.append(d)
            tmp = self._store_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self._store_path)
        except Exception:
            return

    def list(self, opportunity_id: Optional[int] = None, limit: int = 200) -> List[Experiment]:
        items = list(self._items.values())
        if opportunity_id is not None:
            items = [e for e in items if e.opportunity_id == opportunity_id]
        items.sort(key=lambda e: e.created_at, reverse=True)
        return items[:limit]

    def get(self, experiment_id: int) -> Optional[Experiment]:
        return self._items.get(experiment_id)

    def create(self, data: ExperimentCreate) -> Experiment:
        exp = Experiment(id=self._next_id, created_at=datetime.utcnow(), **data.model_dump())
        self._items[self._next_id] = exp
        self._next_id += 1
        self._save()
        return exp

    def update(self, experiment_id: int, data: ExperimentUpdate) -> Optional[Experiment]:
        existing = self._items.get(experiment_id)
        if not existing:
            return None
        upd = data.model_dump(exclude_unset=True)
        exp = existing.model_copy(update=upd)
        self._items[experiment_id] = exp
        self._save()
        return exp

    def delete(self, experiment_id: int) -> bool:
        ok = self._items.pop(experiment_id, None) is not None
        if ok:
            self._save()
        return ok


experiment_registry = ExperimentRegistry()
