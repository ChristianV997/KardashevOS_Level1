from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field


class Equation(BaseModel):
    id: int
    name: str
    latex: str
    domain: str = "unknown"  # e.g. 'cosmology', 'gravity', 'mind'
    status: str = "candidate"  # e.g. 'candidate', 'retired', 'favored'
    gps_score: Optional[float] = Field(
        default=None, description="Global Priority Score (0–1) for this equation."
    )
    notes: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
