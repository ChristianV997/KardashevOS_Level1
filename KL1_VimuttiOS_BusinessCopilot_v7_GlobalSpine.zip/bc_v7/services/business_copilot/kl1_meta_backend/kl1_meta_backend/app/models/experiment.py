from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class Experiment(BaseModel):
    """A lightweight experiment record.

    Stored separately from ResearchItems so we can run clean evals and do
    outcome-driven adaptation ("did it work?") without polluting the signal store.
    """

    id: int
    opportunity_id: int = Field(..., description="ResearchItem.id for the opportunity")
    name: str
    hypothesis: str
    test_type: str = Field(..., description="e.g., outreach|landing|ads|pricing|script")
    status: str = Field("planned", description="planned|running|completed|killed")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None

    cost_usd: float = 0.0
    effort_hours: float = 0.0

    # Core metrics (free-form but should be numeric where possible)
    metrics: Dict[str, Any] = Field(default_factory=dict)

    notes: Optional[str] = None
