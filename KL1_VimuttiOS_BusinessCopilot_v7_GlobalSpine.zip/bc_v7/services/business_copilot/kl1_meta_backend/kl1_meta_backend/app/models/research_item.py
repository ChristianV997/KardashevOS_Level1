from datetime import datetime
from pydantic import BaseModel, Field
from typing import Any, List, Optional


class ResearchItem(BaseModel):
    id: int
    title: str
    source: str = "unknown"
    url: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    gps_score: Optional[float] = Field(
        default=None, description="Global Priority Score (0–1)."
    )
    summary: Optional[str] = None
    payload: Optional[dict[str, Any]] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
