from fastapi import FastAPI

from .core.config import settings
from .api.v1.endpoints import (
    health,
    research_items,
    equations,
    agents,
    world,
    opportunities,
    evals,
    market_scout,
    experiments,
    outbound,
    sieve,
    global_spine,
)

app = FastAPI(title=settings.app_name, debug=settings.debug)

# Health
app.include_router(health.router, tags=["health"])

# Core APIs
app.include_router(
    research_items.router,
    prefix="/api/v1/research_items",
    tags=["research_items"],
)
app.include_router(
    equations.router,
    prefix="/api/v1/equations",
    tags=["equations"],
)
app.include_router(
    agents.router,
    prefix="/api/v1/agents",
    tags=["agents"],
)
app.include_router(
    world.router,
    prefix="/api/v1/world",
    tags=["world"],
)

# Business pilot APIs
app.include_router(
    opportunities.router,
    prefix="/api/v1/opportunities",
    tags=["opportunities"],
)
app.include_router(
    market_scout.router,
    prefix="/api/v1/market_scout",
    tags=["market_scout"],
)
app.include_router(
    evals.router,
    prefix="/api/v1/evals",
    tags=["evals"],
)

app.include_router(
    experiments.router,
    prefix="/api/v1/experiments",
    tags=["experiments"],
)

app.include_router(
    outbound.router,
    prefix="/api/v1/outbound",
    tags=["outbound"],
)

app.include_router(
    sieve.router,
    prefix="/api/v1/sieve",
    tags=["sieve"],
)

# Global spine APIs
app.include_router(
    global_spine.router,
    prefix="/api/v1/global",
    tags=["global"],
)


@app.get("/")
def index() -> dict:
    return {
        "message": "KL1 / VimuttiOS MetaEngine v7",
        "endpoints": [
            "/health",
            "/api/v1/research_items/",
            "/api/v1/equations/",
            "/api/v1/agents/",
            "/api/v1/world/graph",
            "/api/v1/opportunities/",
            "/api/v1/market_scout/ingest/csv",
            "/api/v1/market_scout/ingest/text",
            "/api/v1/evals/run",
            "/api/v1/experiments/",
            "/api/v1/outbound/generate",
            "/api/v1/outbound/campaigns",
            "/api/v1/sieve/cluster",
            "/api/v1/sieve/generate_opportunities",
            "/api/v1/global/run",
            "/api/v1/global/waves",
            "/api/v1/global/opportunities",
        ],
    }
