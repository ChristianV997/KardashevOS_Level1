from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query

from ....schemas.experiment import ExperimentCreate, ExperimentOut, ExperimentUpdate
from ....services.experiment_registry import experiment_registry
from ....services.research_registry import research_registry
from ....services.experiment_engine import adapt_opportunity_from_experiment

router = APIRouter()


@router.get("/", response_model=List[ExperimentOut])
def list_experiments(
    opportunity_id: Optional[int] = Query(default=None),
    limit: int = Query(default=200, ge=1, le=2000),
):
    return experiment_registry.list(opportunity_id=opportunity_id, limit=limit)


@router.post("/", response_model=ExperimentOut)
def create_experiment(data: ExperimentCreate):
    # validate referenced opportunity exists
    opp = research_registry.get(data.opportunity_id)
    if not opp or "opportunity" not in (opp.tags or []):
        raise HTTPException(status_code=404, detail="Opportunity not found (ResearchItem with tag 'opportunity')")
    return experiment_registry.create(data)


@router.get("/{experiment_id}", response_model=ExperimentOut)
def get_experiment(experiment_id: int):
    exp = experiment_registry.get(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return exp


@router.patch("/{experiment_id}", response_model=ExperimentOut)
def update_experiment(experiment_id: int, data: ExperimentUpdate):
    exp = experiment_registry.update(experiment_id, data)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return exp


@router.post("/{experiment_id}/complete")
def complete_experiment(experiment_id: int) -> Dict[str, Any]:
    """Mark an experiment as completed and trigger opportunity adaptation."""
    exp = experiment_registry.get(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")

    # Ensure status completed
    exp2 = experiment_registry.update(experiment_id, ExperimentUpdate(status="completed", ended_at=exp.ended_at))
    exp = exp2 or exp

    opp = research_registry.get(exp.opportunity_id)
    if not opp:
        raise HTTPException(status_code=404, detail="Linked opportunity not found")

    # Feed key costs into metrics if missing
    metrics = dict(exp.metrics or {})
    metrics.setdefault("cost_usd", exp.cost_usd)
    metrics.setdefault("effort_hours", exp.effort_hours)

    updated_opp, info = adapt_opportunity_from_experiment(opp, metrics)
    return {
        "experiment_id": exp.id,
        "opportunity_id": updated_opp.id,
        "adaptation": info,
        "updated_gps_score": updated_opp.gps_score,
    }