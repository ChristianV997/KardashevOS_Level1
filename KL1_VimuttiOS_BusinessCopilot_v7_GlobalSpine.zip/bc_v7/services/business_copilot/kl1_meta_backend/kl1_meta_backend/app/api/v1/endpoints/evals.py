from typing import Any, Dict, List
from fastapi import APIRouter

from ....services.research_registry import research_registry
from ....services.opportunity_engine import validate_opportunity_item
from ....services.experiment_registry import experiment_registry
from ....schemas.experiment import ExperimentOut
from ....services.outbound_registry import outbound_registry
from ....models.outbound_campaign import OutboundCampaign
from ....services.global_timeseries_registry import load_timeseries
import os
import yaml

router = APIRouter()


def _eval_opportunity_schema() -> dict:
    items = research_registry.list(tag="opportunity", limit=10000)
    failures: List[dict] = []
    for it in items:
        ok, err = validate_opportunity_item(it)
        if not ok:
            failures.append({"id": it.id, "title": it.title, "error": err})
    return {
        "name": "opportunity_payload_schema",
        "passed": len(failures) == 0,
        "details": {"total": len(items), "failures": failures[:50]},
    }


def _eval_gps_bounds() -> dict:
    items = research_registry.list(limit=10000)
    bad = []
    for it in items:
        if it.gps_score is None:
            continue
        if not (0.0 <= float(it.gps_score) <= 1.0):
            bad.append({"id": it.id, "gps_score": it.gps_score})
    return {
        "name": "gps_bounds_0_1",
        "passed": len(bad) == 0,
        "details": {"checked": len(items), "bad": bad[:50]},
    }


def _eval_fingerprint_uniqueness() -> dict:
    items = research_registry.list(limit=10000)
    fps = []
    for it in items:
        payload = it.payload or {}
        meta = payload.get("_meta") if isinstance(payload, dict) else None
        if isinstance(meta, dict) and meta.get("fingerprint"):
            fps.append(meta["fingerprint"])
    dup = len(fps) - len(set(fps))
    return {
        "name": "fingerprint_uniqueness",
        "passed": dup == 0,
        "details": {"items_with_fingerprint": len(fps), "duplicates": dup},
    }


def _eval_experiment_schema() -> dict:
    exps = experiment_registry.list(limit=100000)
    failures = []
    for e in exps:
        try:
            ExperimentOut(**e.model_dump())
        except Exception as err:
            failures.append({"id": getattr(e, "id", None), "error": str(err)})
    return {
        "name": "experiment_schema",
        "passed": len(failures) == 0,
        "details": {"total": len(exps), "failures": failures[:50]},
    }


def _eval_experiment_links() -> dict:
    exps = experiment_registry.list(limit=100000)
    missing = []
    for e in exps:
        opp = research_registry.get(e.opportunity_id)
        if not opp or "opportunity" not in (opp.tags or []):
            missing.append({"experiment_id": e.id, "opportunity_id": e.opportunity_id})
    return {
        "name": "experiment_opportunity_links",
        "passed": len(missing) == 0,
        "details": {"total": len(exps), "missing": missing[:50]},
    }


def _eval_outbound_schema() -> dict:
    camps = outbound_registry.list(limit=100000)
    failures = []
    for c in camps:
        try:
            OutboundCampaign(**c.model_dump())
        except Exception as err:
            failures.append({"id": getattr(c, "id", None), "error": str(err)})
    return {
        "name": "outbound_campaign_schema",
        "passed": len(failures) == 0,
        "details": {"total": len(camps), "failures": failures[:50]},
    }


def _eval_outbound_experiment_links() -> dict:
    camps = outbound_registry.list(limit=100000)
    missing = []
    for c in camps:
        if c.experiment_id is None:
            continue
        if not experiment_registry.get(c.experiment_id):
            missing.append({"campaign_id": c.id, "experiment_id": c.experiment_id})
    return {
        "name": "outbound_experiment_links",
        "passed": len(missing) == 0,
        "details": {"total": len(camps), "missing": missing[:50]},
    }


def _eval_global_sources_schema() -> dict:
    """Validate the global sources YAML configuration file.

    When the KL1_GLOBAL_SOURCES environment variable is unset, this check
    falls back to the default `app/data/global_sources.yaml` location. The
    original implementation only navigated three levels up from this file
    (app/api/v1/endpoints/evals.py) and erroneously appended `data/global_sources.yaml`
    relative to `app/api`, which resolved to `app/api/data/global_sources.yaml`.
    However, the `global_sources.yaml` file resides in `app/data`. To fix this
    mismatch we climb one extra directory (four parents instead of three) so
    that the fallback path points to `app/data/global_sources.yaml`.
    """
    path: str | None = os.getenv("KL1_GLOBAL_SOURCES")
    if not path:
        # Compute default by climbing four directories up from this file
        # __file__ points to app/api/v1/endpoints/evals.py. Moving up four
        # levels yields the `app` directory. Then append `data/global_sources.yaml`.
        base_dir = os.path.dirname(
            os.path.dirname(
                os.path.dirname(os.path.dirname(__file__))
            )
        )
        path = os.path.join(base_dir, "data", "global_sources.yaml")
    try:
        with open(path, "r", encoding="utf-8") as f:
            yaml.safe_load(f)
        return {
            "name": "global_sources_schema",
            "passed": True,
            "details": {"path": path},
        }
    except Exception as err:
        return {
            "name": "global_sources_schema",
            "passed": False,
            "details": {"path": path, "error": str(err)},
        }


def _eval_global_timeseries_store_schema() -> dict:
    """Validate the global timeseries JSON store.

    Checks that the file exists (if any) and is a mapping from string keys to
    lists. Empty or missing files are considered valid; detailed validation
    happens in the engine.
    """
    ts = load_timeseries()
    ok = isinstance(ts, dict) and all(isinstance(v, list) for v in ts.values())
    return {
        "name": "global_timeseries_store_schema",
        "passed": ok,
        "details": {"series_count": len(ts)},
    }


@router.get("/run")
def run_evals() -> Dict[str, Any]:
    results = [
        _eval_fingerprint_uniqueness(),
        _eval_gps_bounds(),
        _eval_opportunity_schema(),
        _eval_experiment_schema(),
        _eval_experiment_links(),
        _eval_outbound_schema(),
        _eval_outbound_experiment_links(),
        _eval_global_sources_schema(),
        _eval_global_timeseries_store_schema(),
    ]
    passed = all(r.get("passed") for r in results)
    return {"passed": passed, "results": results}
