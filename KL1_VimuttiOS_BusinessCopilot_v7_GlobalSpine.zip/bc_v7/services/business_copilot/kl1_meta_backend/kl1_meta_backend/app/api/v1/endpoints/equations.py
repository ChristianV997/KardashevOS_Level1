from typing import List, Optional
from fastapi import APIRouter, HTTPException
from ....schemas.equation import EquationCreate, EquationRead, EquationUpdate
from ....services.equation_registry import equation_registry

router = APIRouter()


@router.get("/", response_model=List[EquationRead])
def list_equations(domain: Optional[str] = None, limit: int = 100):
    return equation_registry.list(domain=domain, limit=limit)


@router.post("/", response_model=EquationRead, status_code=201)
def create_equation(data: EquationCreate):
    return equation_registry.create(data)


@router.get("/{eq_id}", response_model=EquationRead)
def get_equation(eq_id: int):
    eq = equation_registry.get(eq_id)
    if not eq:
        raise HTTPException(status_code=404, detail="Equation not found")
    return eq


@router.patch("/{eq_id}", response_model=EquationRead)
def update_equation(eq_id: int, data: EquationUpdate):
    eq = equation_registry.update(eq_id, data)
    if not eq:
        raise HTTPException(status_code=404, detail="Equation not found")
    return eq


@router.delete("/{eq_id}", status_code=204)
def delete_equation(eq_id: int):
    ok = equation_registry.delete(eq_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Equation not found")
    return
