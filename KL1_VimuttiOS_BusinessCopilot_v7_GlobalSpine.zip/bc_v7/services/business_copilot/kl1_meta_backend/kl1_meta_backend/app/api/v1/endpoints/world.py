from fastapi import APIRouter
from ....schemas.world_layer import WorldGraphRead
from ....services.world_layer import world_layer_service

router = APIRouter()


@router.get("/graph", response_model=WorldGraphRead)
def get_world_graph():
    nodes, edges = world_layer_service.get_graph()
    return WorldGraphRead(nodes=nodes, edges=edges)
