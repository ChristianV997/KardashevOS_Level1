from typing import List, Optional
from fastapi import APIRouter, HTTPException

from ....schemas.research_item import ResearchItemRead, ResearchItemUpdate
from ....schemas.opportunity import OpportunityCreate, OpportunityUpdate, OpportunityScoreRequest, OpportunityPayload
from ....services.opportunity_engine import (
    create_opportunity_item,
    list_opportunities,
    update_opportunity_item,
    compute_gps,
    validate_opportunity_item,
)
from ....services.research_registry import research_registry

router = APIRouter()


@router.get("/", response_model=List[ResearchItemRead])
def list_opps(niche: Optional[str] = None, limit: int = 100):
    return list_opportunities(niche=niche, limit=limit)


@router.post("/", response_model=ResearchItemRead, status_code=201)
def create_opp(data: OpportunityCreate):
    return create_opportunity_item(
        title=data.title,
        source=data.source,
        url=data.url,
        tags=data.tags,
        summary=data.summary,
        opportunity=data.opportunity,
    )


@router.patch("/{item_id}", response_model=ResearchItemRead)
def patch_opp(item_id: int, data: OpportunityUpdate):
    existing = research_registry.get(item_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Opportunity not found")

    # If full opportunity payload provided, update it
    if data.opportunity:
        updated = update_opportunity_item(item_id, data.opportunity, recompute=data.recompute_score)
        if not updated:
            raise HTTPException(status_code=404, detail="Opportunity not found")
    else:
        # Partial update only on research item fields
        updated = research_registry.update(
            item_id,
            ResearchItemUpdate(
                title=data.title,
                url=data.url,
                tags=data.tags,
                summary=data.summary,
            ),
        )
        if not updated:
            raise HTTPException(status_code=404, detail="Opportunity not found")

    return updated


@router.post("/{item_id}/score", response_model=ResearchItemRead)
def score_opp(item_id: int, req: OpportunityScoreRequest):
    existing = research_registry.get(item_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    p = (existing.payload or {}).get("opportunity")
    if not p:
        raise HTTPException(status_code=400, detail="Item is missing payload.opportunity")
    opp = OpportunityPayload(**p)
    opp.features = req.features
    opp.weights = req.weights
    updated = update_opportunity_item(item_id, opp, recompute=True)
    if not updated:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    return updated


@router.get("/{item_id}/validate")
def validate_opp(item_id: int):
    item = research_registry.get(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    ok, msg = validate_opportunity_item(item)
    return {"ok": ok, "message": msg}
