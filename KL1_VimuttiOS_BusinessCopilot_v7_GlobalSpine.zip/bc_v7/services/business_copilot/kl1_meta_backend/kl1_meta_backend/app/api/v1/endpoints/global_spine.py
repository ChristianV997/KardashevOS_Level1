"""
API endpoints for the global spine.

These endpoints expose the global ingestion, analytics and opportunity draft
functionalities described in the Global Money Flows Digestor. All routes are
prefixed under ``/api/v1/global`` by the application router configuration.
"""

from fastapi import APIRouter, Query
from typing import Any, Dict

from ....services.global_engine import run_global_spine, compute_global_waves, create_global_opportunities


router = APIRouter()


@router.post("/run")
def run_global(*, dry_run: bool = Query(False, description="If true, seed synthetic data instead of fetching live.")) -> Dict[str, Any]:
    """Trigger the global ingestion loop.

    When ``dry_run`` is true the engine generates synthetic series for the configured
    FRED series. Otherwise this endpoint will return immediately with a
    no‑operation result. The response summarises how many signals were created
    and how many series were updated.
    """
    return run_global_spine(dry_run=dry_run)


@router.get("/waves")
def get_waves() -> Dict[str, Any]:
    """Return a ranking of recent macro waves.

    The response contains a timestamp and a list of dictionaries with
    ``series`` and ``delta`` fields sorted by absolute change descending.
    """
    return compute_global_waves()


@router.post("/opportunities")
def draft_opportunities(*, top_n: int = Query(5, ge=1, le=20, description="How many top macro series to convert into opportunities")) -> Dict[str, Any]:
    """Draft new opportunities based on the most significant macro movements.

    This endpoint selects the ``top_n`` series with the largest absolute changes
    from the waves ranking and generates an opportunity for each. The
    opportunities are persisted via the opportunity engine and their identifiers
    are returned. It is idempotent and can be called repeatedly.
    """
    return create_global_opportunities(top_n=top_n)
