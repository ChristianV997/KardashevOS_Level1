from typing import List
from pydantic import BaseModel
from ..models.world_layer import WorldNode, WorldEdge


class WorldGraphRead(BaseModel):
    nodes: List[WorldNode]
    edges: List[WorldEdge]
