from datetime import datetime
from typing import Any, List, Optional
from pydantic import BaseModel, Field


class ResearchItemBase(BaseModel):
    title: str
    source: str = "unknown"
    url: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    gps_score: Optional[float] = None
    summary: Optional[str] = None
    payload: Optional[dict[str, Any]] = None


class ResearchItemCreate(ResearchItemBase):
    pass


class ResearchItemUpdate(BaseModel):
    title: Optional[str] = None
    source: Optional[str] = None
    url: Optional[str] = None
    tags: Optional[List[str]] = None
    gps_score: Optional[float] = None
    summary: Optional[str] = None
    payload: Optional[dict[str, Any]] = None


class ResearchItemRead(ResearchItemBase):
    id: int
    created_at: datetime
