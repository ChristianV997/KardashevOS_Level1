from pydantic import BaseModel


class Settings(BaseModel):
    app_name: str = "KL1 MetaEngine v7"
    debug: bool = True


settings = Settings()
