"""Stub module for python_multipart.

FastAPI performs a runtime import check for the ``python_multipart`` package
to enable form and file uploads. The real package is not available in this
environment, but for endpoints that do not actually handle multipart form
data this empty stub satisfies the import and prevents FastAPI from
raising a runtime error during application start‑up.
"""
