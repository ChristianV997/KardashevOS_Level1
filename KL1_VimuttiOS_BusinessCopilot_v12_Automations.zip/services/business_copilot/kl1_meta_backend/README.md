# KL1 Meta Backend

Minimal FastAPI application exposing:

- `/api/v1/research_items/`
- `/api/v1/equations/`
- `/api/v1/agents/`
- `/api/v1/world/graph`
- `/health`

ResearchItems are persisted to a JSON store by default (see below). Swap the services layer for DB-backed
implementations when you're ready.

## Run

```bash
cd kl1_meta_backend
uvicorn kl1_meta_backend.app.main:app --reload
```

Then open http://127.0.0.1:8000/docs for interactive Swagger UI.


## Opportunity Engine (Patch 1)

New endpoints:
- `/api/v1/opportunities/` (create/list/update opportunities backed by ResearchItem + payload schema)
- `/api/v1/evals/run` (minimal eval suite: opportunity schema + GPS bounds)

Persistence:
- ResearchItems are now persisted to `kl1_meta_backend/kl1_meta_backend/app/data/research_items.json` by default.
- Override path with env var: `KL1_RESEARCH_STORE=/path/to/research_items.json`
