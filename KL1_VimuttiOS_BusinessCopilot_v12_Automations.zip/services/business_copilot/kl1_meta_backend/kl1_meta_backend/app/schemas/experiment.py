from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class ExperimentBase(BaseModel):
    opportunity_id: int = Field(..., description="ResearchItem.id for the opportunity")
    name: str
    hypothesis: str
    test_type: str = Field(..., description="outreach|landing|ads|pricing|script|other")
    status: str = Field("planned", description="planned|running|completed|killed")

    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None

    cost_usd: float = 0.0
    effort_hours: float = 0.0
    metrics: Dict[str, Any] = Field(default_factory=dict)
    notes: Optional[str] = None


class ExperimentCreate(ExperimentBase):
    pass


class ExperimentUpdate(BaseModel):
    name: Optional[str] = None
    hypothesis: Optional[str] = None
    test_type: Optional[str] = None
    status: Optional[str] = None
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    cost_usd: Optional[float] = None
    effort_hours: Optional[float] = None
    metrics: Optional[Dict[str, Any]] = None
    notes: Optional[str] = None


class ExperimentOut(BaseModel):
    id: int
    opportunity_id: int
    name: str
    hypothesis: str
    test_type: str
    status: str
    created_at: datetime
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    cost_usd: float
    effort_hours: float
    metrics: Dict[str, Any]
    notes: Optional[str] = None
