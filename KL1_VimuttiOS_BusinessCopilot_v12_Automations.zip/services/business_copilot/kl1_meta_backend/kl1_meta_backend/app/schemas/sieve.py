from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class SieveClusterRequest(BaseModel):
    item_type: str = Field(default="signal", description="payload type to cluster (e.g., signal, lead)")
    tags_any: Optional[List[str]] = Field(default=None, description="Optional: require at least one tag")
    limit: int = Field(default=300, ge=1, le=5000)
    similarity_threshold: float = Field(default=0.35, ge=0.0, le=0.95)
    min_cluster_size: int = Field(default=2, ge=1, le=100)


class ClusterItem(BaseModel):
    item_id: int
    title: str
    source: str
    url: Optional[str] = None
    summary: Optional[str] = None
    tags: List[str] = Field(default_factory=list)


class ClusterRead(BaseModel):
    cluster_id: str
    label: str
    size: int
    keywords: List[str] = Field(default_factory=list)
    item_ids: List[int] = Field(default_factory=list)
    items_preview: List[ClusterItem] = Field(default_factory=list)


class SieveClusterResponse(BaseModel):
    item_type: str
    threshold: float
    total_items: int
    clusters: List[ClusterRead] = Field(default_factory=list)


class SieveGenerateOpportunitiesRequest(BaseModel):
    item_type: str = Field(default="signal")
    tags_any: Optional[List[str]] = None
    limit: int = Field(default=300, ge=1, le=5000)
    similarity_threshold: float = Field(default=0.35, ge=0.0, le=0.95)
    min_cluster_size: int = Field(default=2, ge=1, le=100)
    source: str = Field(default="sieve")
    base_tags: List[str] = Field(default_factory=lambda: ["auto", "sieve"])
    default_offer_tier: str = Field(default="A", description="A=Quickstart, B=Retainer, C=SaaS")


class GeneratedOpportunity(BaseModel):
    opportunity_item_id: int
    gps_score: float
    title: str
    niche: str
    offer_tier: str
    cluster_id: str


class SieveGenerateOpportunitiesResponse(BaseModel):
    created: int
    created_opportunities: List[GeneratedOpportunity] = Field(default_factory=list)
    clusters_considered: int
    skipped_small_clusters: int


class LeadSieveGenerateRequest(BaseModel):
    """Generate initial opportunities from a lead batch.

    Goal: when you ingest a CSV of leads, the OS should propose opportunities automatically.
    """

    lead_tag: str = Field(..., description="Tag used to mark the lead batch (recommended: unique batch tag)")
    group_field: str = Field(
        default="industry",
        description="Which lead field to group by (industry|category|niche|service|vertical).",
    )
    min_group_size: int = Field(default=5, ge=1, le=500)
    default_offer_tier: str = Field(default="A")
    source: str = Field(default="lead_sieve")
    base_tags: List[str] = Field(default_factory=lambda: ["auto", "lead_sieve"])


class LeadSieveGenerated(BaseModel):
    niche: str
    lead_count: int
    opportunity_item_id: int
    gps_score: float


class LeadSieveGenerateResponse(BaseModel):
    created: int
    created_opportunities: List[LeadSieveGenerated] = Field(default_factory=list)
    lead_tag: str
    group_field: str
