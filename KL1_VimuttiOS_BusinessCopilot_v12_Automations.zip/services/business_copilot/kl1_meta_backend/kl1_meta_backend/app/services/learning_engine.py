"""
Learning spine engine for books & courses frameworks.

This module implements a simple "Books/Courses Digestor" that ingests
configured books and courses, extracts conceptual frameworks and converts
them into operational assets. It supports a dry‑run mode for offline
environments where external content cannot be fetched. In dry‑run mode
the engine generates sample frameworks for each source. In future
iterations this module could leverage a language model to parse real
books or course transcripts.

Functions provided:

* run_learning_spine(dry_run): ingest configured sources and extract
  frameworks. Returns a summary of how many frameworks were created.
* compute_learning_frameworks(): return a list of extracted frameworks
  grouped by source.
* create_learning_sops(top_n): convert the top frameworks into
  opportunities (SOPs/checklists) and return their identifiers.

The YAML configuration file is loaded from ``KL1_LEARNING_SOURCES`` or
defaults to ``app/data/learning_sources.yaml``. It should contain
``books`` and/or ``courses`` lists with objects specifying a
``title`` and optional metadata. See the provided sample in
``integration/learning_sources.yaml``.
"""

from __future__ import annotations

import os
import random
from typing import Any, Dict, List, Optional

import yaml

from ..schemas.research_item import ResearchItemCreate
from ..schemas.opportunity import OpportunityPayload, OpportunityFeatures
from ..services.research_registry import research_registry
from ..services.opportunity_engine import create_opportunity_item


def _load_learning_sources() -> Dict[str, Any]:
    """Load the YAML file describing learning sources.

    The location is determined by the ``KL1_LEARNING_SOURCES`` environment
    variable. If unset, we fall back to ``app/data/learning_sources.yaml``
    relative to this module. Returns an empty dict if the file cannot be
    read or parsed.
    """
    cfg_path = os.getenv("KL1_LEARNING_SOURCES")
    if not cfg_path:
        # locate app/data relative to this file
        cfg_path = str(
            (__file__ and os.path)
            and (os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "learning_sources.yaml"))
        )
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return data or {}
    except Exception:
        return {}


def _create_framework_item(
    source_title: str,
    framework_name: str,
    description: str,
    tags: Optional[List[str]] = None,
) -> int:
    """Create or update a research item representing a learning framework.

    Each framework is stored with a payload containing a fingerprint to avoid
    duplication. Returns the ID of the saved item.
    """
    tags = tags or []
    base_tags = ["learning", "framework", f"source:{source_title}"]
    merged_tags = list(dict.fromkeys(base_tags + tags))
    payload = {
        "_meta": {
            "type": "learning_framework",
            "source_title": source_title,
            "framework_name": framework_name,
        },
        "source_title": source_title,
        "framework_name": framework_name,
        "description": description,
    }
    item = ResearchItemCreate(
        title=f"Framework: {framework_name}",
        source="learning_spine",
        url=None,
        tags=merged_tags,
        summary=description,
        payload=payload,
    )
    saved, _ = research_registry.upsert_by_fingerprint(item)
    return saved.id


def run_learning_spine(*, dry_run: bool = False) -> Dict[str, Any]:
    """Execute the learning ingestion loop.

    In dry‑run mode, synthetic frameworks are generated for each configured
    source. In normal mode this function would parse real books/courses using
    an LLM or other extraction pipeline; since internet access may not be
    available it currently acts as a no‑op when ``dry_run=False``.

    Returns a dictionary summarizing the operation, including the number of
    frameworks created and sources processed.
    """
    sources = _load_learning_sources()
    books: List[Any] = sources.get("books", []) or []
    courses: List[Any] = sources.get("courses", []) or []
    sources_list: List[Dict[str, Any]] = []
    # Normalize books and courses to a uniform list with title
    for entry in books:
        if isinstance(entry, dict) and entry.get("title"):
            sources_list.append({"title": str(entry.get("title")), "type": "book"})
        elif isinstance(entry, str):
            sources_list.append({"title": str(entry), "type": "book"})
    for entry in courses:
        if isinstance(entry, dict) and entry.get("title"):
            sources_list.append({"title": str(entry.get("title")), "type": "course"})
        elif isinstance(entry, str):
            sources_list.append({"title": str(entry), "type": "course"})
    created_count = 0
    if dry_run:
        # For each source create a handful of synthetic frameworks
        for src in sources_list:
            title = src["title"]
            # Generate between 2 and 4 frameworks per source
            num_fw = random.randint(2, 4)
            for i in range(num_fw):
                fw_name = f"{title.split()[0]} Framework {i+1}"
                desc = f"Synthetic framework {i+1} extracted from {title} (dry run)"
                _create_framework_item(title, fw_name, desc)
                created_count += 1
        return {"sources_processed": len(sources_list), "frameworks_created": created_count}
    else:
        # TODO: Real ingestion would parse books/courses to extract frameworks.
        return {"sources_processed": len(sources_list), "frameworks_created": 0, "message": "dry_run=false mode not implemented"}


def compute_learning_frameworks() -> Dict[str, Any]:
    """Return a mapping of sources to frameworks stored in the research registry.

    This helper iterates over all research items tagged with "learning" and
    groups their titles by source_title. The returned dictionary contains a
    list of frameworks for each source.
    """
    items = research_registry.list(tag="learning", limit=10000)
    frameworks: Dict[str, List[Dict[str, str]]] = {}
    for it in items:
        payload = it.payload or {}
        source_title = payload.get("source_title") or "unknown"
        framework_name = payload.get("framework_name") or it.title
        frameworks.setdefault(source_title, []).append({"name": framework_name, "summary": it.summary})
    return {"frameworks": frameworks}


def _sop_template(framework_name: str) -> OpportunityPayload:
    """Create a simple SOP opportunity payload for a given framework.

    The returned OpportunityPayload uses generic values for niche and offer
    tier and sets all feature scores to 0.5 as a neutral baseline.
    """
    name = f"{framework_name} Implementation"
    problem = f"Lack of standardized application of {framework_name} causing inefficiency."
    proposed_offer = f"Design and implement the {framework_name} as a standard operating procedure with checklist and training."
    features = OpportunityFeatures(
        pain=0.5,
        budget=0.5,
        reachability=0.5,
        speed=0.5,
        fulfillment_fit=0.5,
        moat=0.5,
        risk=0.5,
        load=0.5,
    )
    return OpportunityPayload(
        niche="general",
        offer_tier="B",
        name=name,
        problem=problem,
        proposed_offer=proposed_offer,
        features=features,
    )


def create_learning_sops(*, top_n: int = 5) -> Dict[str, Any]:
    """Draft new opportunities (SOPs) from the most recent frameworks.

    This selects up to ``top_n`` frameworks (ordered by recency) and
    converts each into an opportunity via the opportunity engine. The
    identifiers of the created opportunities are returned. If fewer
    frameworks exist, all available ones are used.
    """
    items = research_registry.list(tag="learning", limit=10000)
    # Sort by updated_at or created_at descending if available
    items_sorted = sorted(items, key=lambda x: getattr(x, "updated_at", getattr(x, "created_at", 0)), reverse=True)
    top_items = items_sorted[: max(1, min(top_n, len(items_sorted)))]
    created_ids: List[int] = []
    for it in top_items:
        payload = it.payload or {}
        framework_name = payload.get("framework_name") or it.title
        opp_payload = _sop_template(framework_name)
        title = f"SOP: {framework_name}"
        summary = f"Draft SOP for {framework_name} based on extracted framework."
        # Use tags to mark it as derived from learning
        tags = ["learning", "sop", framework_name]
        # create opportunity item with required source and url parameters
        item = create_opportunity_item(
            title=title,
            source="learning_spine",
            url=None,
            tags=tags,
            summary=summary,
            opportunity=opp_payload,
        )
        item_id = item.id
        created_ids.append(item_id)
    return {"created": created_ids}