from typing import Dict, List, Optional
from ..models.agent_state import AgentState
from ..schemas.agent_state import AgentStateCreate, AgentStateUpdate


class AgentOrchestrator:
    def __init__(self) -> None:
        self._agents: Dict[str, AgentState] = {}

    def list(self) -> List[AgentState]:
        return list(self._agents.values())

    def get(self, name: str) -> Optional[AgentState]:
        return self._agents.get(name)

    def create(self, data: AgentStateCreate) -> AgentState:
        state = AgentState(name=data.name, role=data.role, config=data.config)
        self._agents[data.name] = state
        return state

    def update(self, name: str, data: AgentStateUpdate) -> Optional[AgentState]:
        existing = self._agents.get(name)
        if not existing:
            return None
        update_data = data.model_dump(exclude_unset=True)
        updated = existing.model_copy(update=update_data)
        self._agents[name] = updated
        return updated

    def delete(self, name: str) -> bool:
        return self._agents.pop(name, None) is not None


agent_orchestrator = AgentOrchestrator()
