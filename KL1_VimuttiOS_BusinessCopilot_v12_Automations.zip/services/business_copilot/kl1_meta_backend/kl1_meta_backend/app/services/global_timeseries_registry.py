"""
Global timeseries registry.

This helper persists macro and market time‑series data to a JSON file. The
store location can be customized via the ``KL1_GLOBAL_TIMESERIES_STORE``
environment variable; otherwise a default path under ``app/data`` is used.

The timeseries file stores a mapping from series names to lists of numeric
values. No interpretation is applied at this layer – higher‑level code can
compute waves, deltas or other analytics on top of the raw values.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Any


def _default_store_path() -> Path:
    """Return the default path for the timeseries store.

    If the ``KL1_GLOBAL_TIMESERIES_STORE`` environment variable is set it
    takes precedence. Otherwise we fall back to ``app/data/global_timeseries.json``
    relative to this module.
    """
    env_path = os.getenv("KL1_GLOBAL_TIMESERIES_STORE")
    if env_path:
        return Path(env_path)
    # Locate app/data relative to this file (../.. gives kl1_meta_backend/app)
    base = Path(__file__).resolve().parents[2] / "data"
    return base / "global_timeseries.json"


def load_timeseries() -> Dict[str, List[Any]]:
    """Load the complete timeseries store.

    Returns an empty dict if the store does not exist or cannot be parsed.
    """
    path = _default_store_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
        # Unexpected structure – reset to empty
        return {}
    except Exception:
        # Fail‑open: ignore parsing errors and start fresh
        return {}


def save_timeseries(ts: Dict[str, List[Any]]) -> None:
    """Persist the given timeseries mapping to disk.

    Creates parent directories as needed. Writes JSON with UTF‑8 encoding.
    """
    path = _default_store_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(ts, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        # Fail‑open: never crash callers on write errors
        pass
