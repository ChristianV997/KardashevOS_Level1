"""
Global spine engine for macro & market signals.

This module implements a simplified version of the "Global Money Flows Digestor"
described in the project roadmap. It supports two operational modes:

* In **dry‑run** mode the engine synthesizes sample data for each configured
  series without performing any network calls. This allows smoke tests to
  exercise the endpoints without requiring external connectivity.
* In regular mode the engine would fetch real data from FRED, EDGAR or other
  sources. Network calls are intentionally omitted in this offline build; the
  dry‑run mode should be used in environments without internet access.

The engine stores ingested signals as research items via the research registry
and persists numeric series to the global timeseries store. It can also
compute simple "waves" (recent changes) and draft opportunities based on
macro movements.
"""

from __future__ import annotations

import os
import random
from datetime import datetime
from typing import Any, Dict, List, Optional

import yaml

from ..schemas.research_item import ResearchItemCreate
from ..schemas.opportunity import OpportunityPayload, OpportunityFeatures
from ..services.research_registry import research_registry
from ..services.opportunity_engine import create_opportunity_item
from .global_timeseries_registry import load_timeseries, save_timeseries


def _load_global_sources() -> Dict[str, Any]:
    """Load the YAML file describing global sources.

    The location is determined by the ``KL1_GLOBAL_SOURCES`` environment
    variable. If unset, we fall back to ``app/data/global_sources.yaml``
    adjacent to this module. Returns an empty dict if the file cannot be
    read or parsed.
    """
    cfg_path = os.getenv("KL1_GLOBAL_SOURCES")
    if not cfg_path:
        cfg_path = str((__file__ and os.path) and (os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "global_sources.yaml")))
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return data or {}
    except Exception:
        return {}


def _create_signal(title: str, summary: str, series_name: str, tags: Optional[List[str]] = None) -> int:
    """Create or update a research item representing a global signal.

    Each signal is stored with a payload containing a fingerprint to avoid
    duplication. Returns the ID of the saved item.
    """
    tags = tags or []
    base_tags = ["global", "signal", series_name]
    merged_tags = list(dict.fromkeys(base_tags + tags))
    payload = {
        "_meta": {
            "type": "global_signal",
            "series_name": series_name,
        },
        "series_name": series_name,
    }
    item = ResearchItemCreate(
        title=title,
        source="global_spine",
        url=None,
        tags=merged_tags,
        summary=summary,
        payload=payload,
    )
    saved, _ = research_registry.upsert_by_fingerprint(item)
    return saved.id


def run_global_spine(*, dry_run: bool = False) -> Dict[str, Any]:
    """Execute the global ingestion loop.

    In dry‑run mode, synthetic signals and numeric series are generated for
    each series in the FRED configuration. In normal mode this function
    would download data from external APIs; since internet access may not be
    available it currently acts as a no‑op when ``dry_run=False``.

    Returns a dictionary summarizing the operation, including the number of
    signals created and series updated.
    """
    sources = _load_global_sources()
    fred: List[Any] = sources.get("fred", [])
    # Flatten FRED config to a list of series identifiers
    series_ids: List[str] = []
    for entry in fred:
        if isinstance(entry, dict):
            sid = entry.get("id") or entry.get("series")
            if sid:
                series_ids.append(str(sid))
        elif isinstance(entry, str):
            series_ids.append(entry)
    timeseries = load_timeseries()
    created = []
    if dry_run:
        # Generate a simple ascending sequence for each series (12 values)
        for sid in series_ids:
            # Create synthetic values with slight random noise
            values = []
            base = random.uniform(10.0, 100.0)
            for i in range(12):
                values.append(round(base + i * random.uniform(0.1, 1.0), 3))
            timeseries[sid] = values
            # Create/update the signal record
            title = f"Macro series: {sid}"
            summary = f"Synthetic data for {sid} (dry run)"
            item_id = _create_signal(title, summary, sid, tags=["fred"])
            created.append(item_id)
        save_timeseries(timeseries)
        return {"created_signals": len(created), "series_updated": len(series_ids)}
    else:
        # TODO: Real ingestion would fetch EDGAR filings, FRED series and CSVs.
        return {"created_signals": 0, "series_updated": 0, "message": "dry_run=false mode not implemented"}


def compute_global_waves() -> Dict[str, Any]:
    """Compute and rank recent changes across all stored time series.

    The delta is defined as the difference between the most recent value and
    the one before it. Absolute deltas are used for sorting. Returns a
    dictionary with the computation timestamp and a list of waves with
    ``series`` and ``delta`` fields.
    """
    ts = load_timeseries()
    waves: List[Dict[str, Any]] = []
    for name, values in ts.items():
        if not isinstance(values, list) or len(values) < 2:
            continue
        try:
            prev_val = float(values[-2])
            last_val = float(values[-1])
            delta = last_val - prev_val
        except Exception:
            delta = 0.0
        waves.append({"series": name, "delta": delta})
    waves.sort(key=lambda x: abs(x.get("delta", 0.0)), reverse=True)
    return {"computed_at": datetime.utcnow().isoformat(), "waves": waves}


def _infer_macro_category(series: str) -> str:
    """Heuristically map a series identifier to a macro category.

    This mapping is deliberately simple and opinionated. It looks for
    substrings within the series name to decide which playbook to apply.
    """
    s = series.lower()
    if any(k in s for k in ["cpi", "inflation"]):
        return "inflation"
    if any(k in s for k in ["rate", "funds", "yield", "dgs", "interest"]):
        return "rates"
    if any(k in s for k in ["fx", "usd", "eur", "jpy", "gbp"]):
        return "fx"
    if any(k in s for k in ["unrate", "labor", "employment", "job"]):
        return "labor"
    if any(k in s for k in ["oil", "energy", "gas"]):
        return "oil"
    if any(k in s for k in ["sp", "equity", "stock", "equities", "nasdaq"]):
        return "equities"
    if any(k in s for k in ["credit", "spread", "corp"]):
        return "credit_spreads"
    return "general"


def _macro_playbook(category: str) -> Dict[str, str]:
    """Return a descriptive playbook for a given macro category.

    The returned dict contains keys ``name``, ``problem`` and ``proposed_offer``
    used when drafting opportunities. Unknown categories fall back to a
    generic playbook.
    """
    pb = {
        "inflation": {
            "name": "Pricing System Upgrade",
            "problem": "High inflation raises costs, compressing margins.",
            "proposed_offer": "Implement dynamic pricing and cost tracking to protect margins.",
        },
        "rates": {
            "name": "Refinancing & Cash Conversion",
            "problem": "Interest rate movements impact borrowing costs and cash flow.",
            "proposed_offer": "Analyze debt stack and explore refinancing or cash conversion strategies.",
        },
        "fx": {
            "name": "Import/Export Hedging",
            "problem": "Currency volatility affects pricing for international transactions.",
            "proposed_offer": "Set up FX hedging and local sourcing to stabilize costs.",
        },
        "labor": {
            "name": "Recruiting Funnel Automation",
            "problem": "Tight labor markets make hiring slow and expensive.",
            "proposed_offer": "Automate candidate sourcing and nurture funnels to improve hiring velocity.",
        },
        "oil": {
            "name": "Margin Protection & Procurement",
            "problem": "Energy price swings erode profitability.",
            "proposed_offer": "Lock in energy contracts and optimize procurement to manage energy costs.",
        },
        "equities": {
            "name": "Operator Memo & Sector Plays",
            "problem": "Equity market trends reveal changing sentiment across sectors.",
            "proposed_offer": "Create sector playbooks and operator memos to align strategy with market shifts.",
        },
        "credit_spreads": {
            "name": "Working Capital & Alt Financing",
            "problem": "Widening credit spreads signal tightening liquidity.",
            "proposed_offer": "Set up alternative financing and working capital solutions.",
        },
        "general": {
            "name": "Macro Opportunity",
            "problem": "Macro movements create risks and opportunities.",
            "proposed_offer": "Monitor macro trends and adapt pricing and financing strategies accordingly.",
        },
    }
    return pb.get(category, pb["general"])


def create_global_opportunities(*, top_n: int = 5) -> Dict[str, Any]:
    """Draft and save opportunities based on the top macro waves.

    This function computes the latest waves, selects the ``top_n`` series by
    absolute change, maps each to a playbook category, constructs an
    opportunity payload and persists it via the opportunity engine. It
    returns a list of identifiers for the newly created opportunities.
    """
    waves = compute_global_waves().get("waves", [])
    top = waves[: max(1, int(top_n))]
    created = []
    for w in top:
        series = w.get("series")
        if not series:
            continue
        category = _infer_macro_category(series)
        pb = _macro_playbook(category)
        # Assemble opportunity payload
        features = OpportunityFeatures(
            pain=0.7,
            budget=0.7,
            reachability=0.6,
            speed=0.6,
            fulfillment_fit=0.75,
            moat=0.5,
            risk=0.25,
            load=0.3,
        )
        opp = OpportunityPayload(
            niche=category,
            offer_tier="A",
            name=pb["name"],
            problem=pb["problem"],
            proposed_offer=pb["proposed_offer"],
            features=features,
            weights=None,
            gps_score=None,
        )
        title = f"Macro Opportunity: {category}"
        summary = f"Derived from macro series {series}."
        item = create_opportunity_item(
            title=title,
            source="global_macro_mapper",
            url=None,
            tags=["global", "macro", series],
            summary=summary,
            opportunity=opp,
        )
        created.append({"id": item.id, "series": series, "category": category})
    return {"created": created}
