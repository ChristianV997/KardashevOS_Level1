from __future__ import annotations

from typing import Dict, Optional, Tuple


def _safe(v: Optional[str]) -> str:
    return (v or "").strip()


def _greeting(language: str, name: str) -> str:
    n = _safe(name)
    if language == "es":
        return f"Hola {n}," if n else "Hola,"
    return f"Hi {n}," if n else "Hi,"


def _closing(language: str, sender: str) -> str:
    s = _safe(sender) or ""
    if language == "es":
        return f"\n\n— {s}" if s else ""
    return f"\n\n— {s}" if s else ""


def render_vars(
    *,
    language: str,
    channel: str,
    lead: Dict,
    opportunity: Dict,
    sender_name: Optional[str],
    agency_name: Optional[str],
    calendar_link: Optional[str],
) -> Dict[str, str]:
    """Build substitution vars from lead + opportunity.

    Keeps keys stable so templates don't break.
    """
    lead_name = _safe(lead.get("name") or lead.get("contact") or "")
    company = _safe(lead.get("company") or lead.get("business") or "")
    website = _safe(lead.get("website") or lead.get("domain") or "")

    offer_name = _safe(opportunity.get("name") or "")
    niche = _safe(opportunity.get("niche") or "")
    problem = _safe(opportunity.get("problem") or "")

    sender = _safe(sender_name)
    agency = _safe(agency_name)

    # Human-ish labels
    if language == "es":
        short_offer = offer_name or "una mejora rápida"
    else:
        short_offer = offer_name or "a quick improvement"

    cal = _safe(calendar_link)
    if cal and not cal.startswith("http"):
        cal = "https://" + cal

    return {
        "greeting": _greeting(language, lead_name),
        "lead_name": lead_name,
        "company": company,
        "website": website,
        "offer_name": offer_name,
        "short_offer": short_offer,
        "niche": niche,
        "problem": problem,
        "sender_name": sender,
        "agency_name": agency,
        "calendar_link": cal,
        "closing": _closing(language, sender),
        "channel": channel,
    }


def templates(language: str, channel: str, step: int) -> Tuple[Optional[str], str]:
    """Return (subject, body_template) for step.

    Templates are intentionally short and non-spammy.
    """
    if channel not in {"email", "sms", "dm"}:
        channel = "email"
    if language not in {"en", "es"}:
        language = "en"

    if language == "es":
        if channel == "email":
            if step == 1:
                subj = "Idea rápida para {company}" if "{company}" else "Idea rápida"
                body = (
                    "{greeting}\n\n"
                    "Vi {company} y pensé en una mejora simple: {short_offer}.\n"
                    "Suele resolver {problem} y recuperar leads sin trabajo extra.\n\n"
                    "¿Te interesa que te mande 2–3 ideas específicas para tu caso?\n"
                    "{closing}"
                )
            elif step == 2:
                subj = "¿Lo vemos 10 min?"
                body = (
                    "{greeting}\n\n"
                    "Te dejo esto arriba por si se perdió. Si quieres, lo vemos 10 min y te digo si aplica para {company}.\n"
                    "{calendar_link}\n"
                    "{closing}"
                )
            else:
                subj = "Último mensaje"
                body = (
                    "{greeting}\n\n"
                    "Último ping. Si ahora no es prioridad, todo bien.\n"
                    "Si te interesa más adelante, te comparto un ejemplo de cómo lo instalamos en 7 días.\n"
                    "{closing}"
                )
        else:  # sms/dm
            subj = None
            if step == 1:
                body = (
                    "{greeting} Soy {sender_name}. Vi {company}. "
                    "Idea rápida: {short_offer} para resolver {problem}. ¿Te interesa?"
                )
            elif step == 2:
                body = "{greeting} ¿Te mando 2 ideas específicas para {company}?"
            else:
                body = "{greeting} Último ping — lo dejo aquí."
        return subj, body

    # English
    if channel == "email":
        if step == 1:
            subj = "Quick idea for {company}" if "{company}" else "Quick idea"
            body = (
                "{greeting}\n\n"
                "Saw {company} and thought of a simple win: {short_offer}.\n"
                "It usually fixes {problem} and recovers leads without extra work.\n\n"
                "Want me to send 2–3 specific ideas for your setup?\n"
                "{closing}"
            )
        elif step == 2:
            subj = "Worth 10 minutes?"
            body = (
                "{greeting}\n\n"
                "Bumping this in case it got buried. Happy to take 10 minutes and tell you if this fits {company}.\n"
                "{calendar_link}\n"
                "{closing}"
            )
        else:
            subj = "Closing the loop"
            body = (
                "{greeting}\n\n"
                "Last ping — if now isn't the right time, no worries.\n"
                "If you'd like later, I can share a 7-day install example.\n"
                "{closing}"
            )
    else:
        subj = None
        if step == 1:
            body = (
                "{greeting} I'm {sender_name}. Saw {company}. "
                "Quick idea: {short_offer} to fix {problem}. Interested?"
            )
        elif step == 2:
            body = "{greeting} Want 2 quick, specific ideas for {company}?"
        else:
            body = "{greeting} Last ping — I'll leave it here."
    return subj, body
