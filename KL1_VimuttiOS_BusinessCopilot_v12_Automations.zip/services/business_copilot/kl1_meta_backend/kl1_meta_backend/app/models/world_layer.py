from typing import List
from pydantic import BaseModel, Field


class WorldNode(BaseModel):
    id: str
    kind: str  # 'research_item', 'equation', 'concept', etc.
    label: str
    tags: list[str] = Field(default_factory=list)


class WorldEdge(BaseModel):
    source_id: str
    target_id: str
    relation: str  # e.g. 'supports', 'contradicts', 'refines'
    weight: float = 1.0
