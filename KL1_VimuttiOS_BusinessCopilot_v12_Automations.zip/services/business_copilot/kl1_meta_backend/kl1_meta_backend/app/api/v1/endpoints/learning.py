"""
API endpoints for the learning spine.

These endpoints expose ingestion of books and courses, retrieval of extracted
frameworks and drafting of SOP opportunities. All routes are prefixed
under ``/api/v1/learning`` by the application router configuration.
"""

from fastapi import APIRouter, Query
from typing import Any, Dict

from ....services.learning_engine import (
    run_learning_spine,
    compute_learning_frameworks,
    create_learning_sops,
)


router = APIRouter()


@router.post("/run")
def run_learning(*, dry_run: bool = Query(False, description="If true, seed synthetic frameworks instead of parsing real content.")) -> Dict[str, Any]:
    """Trigger the learning ingestion loop.

    When ``dry_run`` is true the engine generates synthetic frameworks for
    each configured source. Otherwise this endpoint currently returns
    immediately with a no‑operation result because real ingestion is
    unimplemented.
    """
    return run_learning_spine(dry_run=dry_run)


@router.get("/frameworks")
def get_frameworks() -> Dict[str, Any]:
    """Return a mapping of sources to extracted frameworks.

    The response contains a dictionary keyed by source title with lists
    of framework names and summaries.
    """
    return compute_learning_frameworks()


@router.post("/sops")
def draft_sops(*, top_n: int = Query(5, ge=1, le=20, description="How many frameworks to convert into SOP opportunities")) -> Dict[str, Any]:
    """Draft new SOP opportunities based on the most recent frameworks.

    This endpoint selects the ``top_n`` most recently updated frameworks and
    generates an opportunity for each using a generic SOP template. The
    identifiers of the created opportunities are returned.
    """
    return create_learning_sops(top_n=top_n)